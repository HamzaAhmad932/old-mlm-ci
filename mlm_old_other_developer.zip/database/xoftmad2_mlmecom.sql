-- phpMyAdmin SQL Dump
-- version 4.7.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Jan 06, 2018 at 11:55 AM
-- Server version: 5.5.58-cll
-- PHP Version: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `xoftmad2_mlmecom`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_cart`
--

CREATE TABLE `tbl_cart` (
  `cart_id` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `created_date` date NOT NULL,
  `total_cart` int(11) NOT NULL DEFAULT '0',
  `is_shipped` int(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_cart`
--

INSERT INTO `tbl_cart` (`cart_id`, `userid`, `created_date`, `total_cart`, `is_shipped`) VALUES
(1, 11, '2016-12-15', 1, 1),
(2, 11, '2016-12-15', 2, 1),
(3, 11, '2016-12-15', 3, 1),
(4, 11, '2016-12-18', 1, 1),
(5, 1, '2017-12-29', 2, 1),
(6, 1, '2017-12-29', 2, 1),
(7, 1, '2017-12-29', 2, 1),
(8, 1, '2017-12-29', 2, 1),
(9, 1, '2017-12-29', 2, 1),
(10, 1, '2017-12-29', 2, 1),
(11, 1, '2017-12-29', 2, 1),
(12, 1, '2017-12-29', 2, 1),
(13, 1, '2017-12-29', 2, 1),
(14, 2, '2017-12-31', 2, 1),
(15, 1, '2017-12-31', 1, 1),
(16, 1, '2018-01-01', 1, 1),
(17, 1, '2018-01-02', 3, 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_cart_product`
--

CREATE TABLE `tbl_cart_product` (
  `id` int(11) NOT NULL,
  `product_cart_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `product_price` double NOT NULL,
  `quantity` int(11) NOT NULL DEFAULT '1',
  `color_id` int(11) NOT NULL,
  `size_id` int(11) NOT NULL,
  `ip` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_cart_product`
--

INSERT INTO `tbl_cart_product` (`id`, `product_cart_id`, `product_id`, `product_price`, `quantity`, `color_id`, `size_id`, `ip`) VALUES
(1, 1, 12, 500, 1, 5, 6, '127.0.0.1'),
(2, 2, 11, 200, 1, 5, 4, '127.0.0.1'),
(3, 2, 14, 100, 1, 5, 3, '127.0.0.1'),
(4, 3, 16, 100, 3, 3, 3, '127.0.0.1'),
(5, 4, 16, 100, 1, 3, 3, '127.0.0.1'),
(6, 11, 11, 300, 2, 0, 0, '127.0.0.1'),
(7, 12, 11, 300, 2, 0, 0, '127.0.0.1'),
(8, 13, 11, 300, 2, 0, 0, '127.0.0.1'),
(9, 14, 11, 300, 2, 0, 0, '127.0.0.1'),
(10, 15, 11, 300, 1, 0, 0, '119.160.97.85'),
(11, 16, 14, 5000, 1, 0, 0, '45.115.85.86'),
(12, 17, 15, 500, 2, 0, 0, '128.199.214.89'),
(13, 17, 14, 5000, 1, 0, 0, '128.199.214.89');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_category`
--

CREATE TABLE `tbl_category` (
  `id` int(11) NOT NULL,
  `category_name` varchar(255) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `modified_date` datetime DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `status` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_category`
--

INSERT INTO `tbl_category` (`id`, `category_name`, `created_by`, `modified_by`, `modified_date`, `created_date`, `status`) VALUES
(1, 'men', 1, NULL, NULL, '2017-04-13 21:03:53', '0'),
(3, 'almon', 1, NULL, NULL, '2017-12-31 20:33:52', '0');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_checkout`
--

CREATE TABLE `tbl_checkout` (
  `checkout_id` int(11) NOT NULL,
  `firstname` varchar(20) NOT NULL,
  `lastname` varchar(20) NOT NULL,
  `address1` text NOT NULL,
  `address2` text NOT NULL,
  `phone` varchar(20) NOT NULL,
  `email` varchar(50) NOT NULL,
  `country` varchar(20) NOT NULL,
  `city` varchar(20) NOT NULL,
  `province` varchar(20) NOT NULL,
  `postcode` varchar(5) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `payment_option` varchar(20) NOT NULL,
  `order_date` datetime NOT NULL,
  `sale_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_checkout`
--

INSERT INTO `tbl_checkout` (`checkout_id`, `firstname`, `lastname`, `address1`, `address2`, `phone`, `email`, `country`, `city`, `province`, `postcode`, `customer_id`, `payment_option`, `order_date`, `sale_id`) VALUES
(1, 'Muhammad Yasin', 'yasin', 'nqa', '', '923356693632', 'faizan6537@gmail.com', 'Pakistan', 'faisalabad', 'punjab', '38000', 1, 'cash', '2017-12-29 15:08:05', 11),
(2, 'Muhammad Yasin', 'xoi', 'nqa', 'xa', '923356693632', 'faizan6537@gmail.com', 'pakistan', 'faisalabad', 'punjab', '38000', 1, 'cash', '2017-12-29 15:18:50', 12),
(3, 'Muhammad Yasin', 'yasin', 'nqa', 'xa', '923356693632', 'faizan6537@gmail.com', 'Pakistan', 'faisalabad', 'punjab', '38000', 1, 'cash', '2017-12-29 15:24:23', 1),
(4, 'yasin', 'xoi', 'nqa', 'xa', '923356693632', 'faizan6537@gmail.com', 'pk', 'faisalabad', 'punjab', '38000', 2, 'cash', '2017-12-31 06:13:45', 2),
(5, 'test', 'w', 'ppp', 'ppp', '11111', 'admin@gmail.com', 'Pak', 'Faisalabad', 'Punjab', '38000', 1, 'cash', '2017-12-31 14:44:49', 3),
(6, 'Nadeem', 'Ahmad', 'ppp', 'ppp', '03214949004', 'xoftmade@gmail.com', 'Pakistan', 'Faisalabad', 'Punjab', '38000', 1, 'cash', '2018-01-01 12:52:29', 4),
(7, 'Faizan', 'Yasin', 'p-5 abc 223311', '11111', '03236693355', 'faizan6537@gmail.com', 'PAKISTAN', 'Faisalabad', 'Punjab', '38000', 3, '', '2018-01-02 12:24:42', 0),
(8, 'Aslam', 'Ahmad', 'madina town', '203', '0343678907', 'admin@gmail.com', 'PAKISTAN', 'Faisalabad', 'Punjab', '38000', 1, 'Cash on Delivery', '2018-01-02 13:39:03', 5);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_color`
--

CREATE TABLE `tbl_color` (
  `id` bigint(20) NOT NULL,
  `color_name` varchar(255) DEFAULT NULL,
  `colorcode` varchar(255) NOT NULL,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `modified_date` datetime DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `status` enum('active','inactive') DEFAULT 'active',
  `status_delete` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_contact`
--

CREATE TABLE `tbl_contact` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_customers`
--

CREATE TABLE `tbl_customers` (
  `customer_id` int(11) NOT NULL,
  `company_name` varchar(255) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `email` text NOT NULL,
  `password` varchar(100) NOT NULL,
  `phone` text NOT NULL,
  `billing_address1` varchar(255) NOT NULL,
  `billing_address2` varchar(255) NOT NULL,
  `billing_city` int(11) NOT NULL,
  `billing_state` int(11) NOT NULL,
  `billing_country` int(11) NOT NULL,
  `billing_zip` varchar(255) NOT NULL,
  `shipping_address1` varchar(255) NOT NULL,
  `shipping_address2` varchar(255) NOT NULL,
  `shipping_city` int(11) NOT NULL,
  `shipping_state` int(11) NOT NULL,
  `shipping_country` int(11) NOT NULL,
  `shipping_zip` varchar(255) NOT NULL,
  `customer_type` int(11) NOT NULL,
  `tax_id` varchar(255) NOT NULL,
  `year` varchar(5) NOT NULL,
  `credit_card_number` varchar(25) NOT NULL,
  `credit_card_cw` varchar(10) NOT NULL,
  `month` varchar(10) NOT NULL,
  `credit_card_type` varchar(255) NOT NULL,
  `website` varchar(255) NOT NULL,
  `social_networks` varchar(255) NOT NULL,
  `facebook` varchar(255) NOT NULL,
  `twitter` varchar(255) NOT NULL,
  `linkdin` varchar(255) NOT NULL,
  `googlePlus` varchar(255) NOT NULL,
  `uploadFile` varchar(255) NOT NULL,
  `status` enum('active','inactive') NOT NULL DEFAULT 'active',
  `created_by` int(11) NOT NULL DEFAULT '0',
  `modified_by` int(11) NOT NULL,
  `created_date` datetime NOT NULL,
  `modified_date` int(11) NOT NULL,
  `is_member` int(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_customers`
--

INSERT INTO `tbl_customers` (`customer_id`, `company_name`, `first_name`, `last_name`, `email`, `password`, `phone`, `billing_address1`, `billing_address2`, `billing_city`, `billing_state`, `billing_country`, `billing_zip`, `shipping_address1`, `shipping_address2`, `shipping_city`, `shipping_state`, `shipping_country`, `shipping_zip`, `customer_type`, `tax_id`, `year`, `credit_card_number`, `credit_card_cw`, `month`, `credit_card_type`, `website`, `social_networks`, `facebook`, `twitter`, `linkdin`, `googlePlus`, `uploadFile`, `status`, `created_by`, `modified_by`, `created_date`, `modified_date`, `is_member`) VALUES
(1, '', 'Faizan', 'Yasin', 'faizan6537@gmail.comx', 'adminp', '923008401908', '', '', 0, 0, 0, '', '', '', 0, 0, 0, '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', 'active', 0, 0, '2017-12-18 16:24:13', 0, 0),
(2, '', 'Faizan', 'Yasin', 'codepans@gmail.com', 'funki(786)', '923356693632', '', '', 0, 0, 0, '', '', '', 0, 0, 0, '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', 'active', 0, 0, '2017-12-28 12:43:18', 0, 0),
(3, '', 'Faizan', 'Yasin', 'faizan6537@gmail.com', 'admin(786)', '03236693355', '', '', 0, 0, 0, '', '', '', 0, 0, 0, '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', 'active', 0, 0, '2018-01-02 11:57:31', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_products`
--

CREATE TABLE `tbl_products` (
  `id` bigint(20) NOT NULL,
  `product_code` varchar(255) DEFAULT NULL,
  `product_name` varchar(200) NOT NULL,
  `product_description` text,
  `product_price` double NOT NULL,
  `pv` text NOT NULL,
  `bv` text NOT NULL,
  `purchase_cost` text NOT NULL,
  `product_type` int(1) NOT NULL,
  `product_image` varchar(5000) NOT NULL,
  `category_id` int(11) DEFAULT NULL,
  `sub_category_id` varchar(500) NOT NULL,
  `color_id` varchar(500) NOT NULL,
  `size_id` varchar(500) NOT NULL,
  `related_product` varchar(200) DEFAULT NULL,
  `quantity` varchar(255) NOT NULL,
  `discount` varchar(255) NOT NULL,
  `gross_amount` varchar(255) NOT NULL,
  `net` varchar(255) NOT NULL,
  `created_date` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `modified_date` datetime DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_products`
--

INSERT INTO `tbl_products` (`id`, `product_code`, `product_name`, `product_description`, `product_price`, `pv`, `bv`, `purchase_cost`, `product_type`, `product_image`, `category_id`, `sub_category_id`, `color_id`, `size_id`, `related_product`, `quantity`, `discount`, `gross_amount`, `net`, `created_date`, `created_by`, `modified_date`, `modified_by`, `status`) VALUES
(11, '010283435610794', 'aaa', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem.', 100, '12', '16', '2000', 1, '3.jpg', 1, '', '', '', '', '2', '1', '100.00', '99.00', '2017-12-28 14:13:06', 1, '2018-01-06 11:39:45', NULL, '0'),
(12, '575163296514989', 'Product 2', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem.', 300, '10', '20', '', 1, '4.jpg', 1, '1', '', '', '11', '100', '0', '30000.00', '30000.00', '2017-12-28 14:20:08', 2, NULL, NULL, '0'),
(13, '202344197835735', 'Product 2', 'lorem ipsume demos', 300, '12', '20', '', 1, 'mlm.jpg', 1, '', '', '', '', '1', '2', '300.00', '294.00', '2018-01-01 00:07:57', 1, '2018-01-02 13:26:28', NULL, '0'),
(14, '663466943075606', 'Test Product', 'Test Product', 5000, '100', '120', '', 1, '03.jpg', 1, '', '', '', '', '1', '20', '5000.00', '4000.00', '2018-01-01 12:48:31', 1, NULL, NULL, '0'),
(15, '763280284137580', 'abc', 'testing testing', 500, '10', '100', '', 1, 'girls-wear-2014-8.jpg', 1, '', '', '', '', '1', '5', '500.00', '475.00', '2018-01-02 13:05:16', 1, '2018-01-02 13:36:57', NULL, '0'),
(16, '443522651627554', 'Adm', 'das', 100, '10', '30', '111', 1, 'asia-technology-2016.jpeg', 1, '', '', '', '11,12,13,14,15', '1', '0', '100.00', '100.00', '2018-01-06 11:40:57', 1, NULL, NULL, '0');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_sales`
--

CREATE TABLE `tbl_sales` (
  `id` int(11) NOT NULL,
  `buyer_name` varchar(100) NOT NULL,
  `cash_discount` int(11) NOT NULL,
  `grand_amount` double NOT NULL,
  `description` varchar(250) NOT NULL,
  `status` enum('active','inactive') NOT NULL DEFAULT 'active',
  `created_by` int(11) NOT NULL,
  `issue_date` date NOT NULL,
  `due_date` date NOT NULL,
  `total_quantity` int(11) NOT NULL,
  `shipped_status` int(11) NOT NULL COMMENT 'orderpace=0,'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_sales`
--

INSERT INTO `tbl_sales` (`id`, `buyer_name`, `cash_discount`, `grand_amount`, `description`, `status`, `created_by`, `issue_date`, `due_date`, `total_quantity`, `shipped_status`) VALUES
(1, 'Muhammad Yasin', 0, 600, '', 'active', 0, '2017-12-29', '0000-00-00', 2, 2),
(2, 'yasin', 0, 600, '', 'active', 0, '2017-12-31', '0000-00-00', 2, 1),
(3, 'test', 0, 300, '', 'active', 0, '2017-12-31', '0000-00-00', 1, 2),
(4, 'Nadeem', 0, 5000, '', 'active', 0, '2018-01-01', '0000-00-00', 1, 1),
(5, 'Aslam', 0, 6000, '', 'active', 0, '2018-01-02', '0000-00-00', 3, 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_sales_detail`
--

CREATE TABLE `tbl_sales_detail` (
  `id` int(11) NOT NULL,
  `sale_id` int(11) NOT NULL,
  `product_code` varchar(255) NOT NULL,
  `selling_rate` double NOT NULL,
  `discount` int(2) NOT NULL,
  `quantity` int(11) NOT NULL,
  `color_id` int(11) NOT NULL,
  `size_id` int(11) NOT NULL,
  `product_price` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_sales_detail`
--

INSERT INTO `tbl_sales_detail` (`id`, `sale_id`, `product_code`, `selling_rate`, `discount`, `quantity`, `color_id`, `size_id`, `product_price`) VALUES
(1, 1, '010283435610794', 0, 0, 2, 0, 0, 300),
(2, 1, '010283435610794', 0, 0, 2, 0, 0, 300),
(3, 1, '010283435610794', 0, 0, 2, 0, 0, 300),
(4, 2, '010283435610794', 0, 0, 2, 0, 0, 300),
(5, 3, '010283435610794', 0, 0, 1, 0, 0, 300),
(6, 4, '663466943075606', 0, 0, 1, 0, 0, 5000),
(7, 5, '663466943075606', 0, 0, 1, 0, 0, 5000),
(8, 5, '763280284137580', 0, 0, 2, 0, 0, 500);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_size`
--

CREATE TABLE `tbl_size` (
  `id` bigint(20) NOT NULL,
  `size` varchar(255) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `modified_date` datetime DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `status` enum('active','inactive') DEFAULT 'active',
  `status_delete` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_slider_images`
--

CREATE TABLE `tbl_slider_images` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `created_by` int(11) NOT NULL,
  `created_date` datetime NOT NULL,
  `modified_by` int(11) NOT NULL,
  `modified_date` datetime NOT NULL,
  `status` enum('active','inactive') NOT NULL,
  `views` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_slider_images`
--

INSERT INTO `tbl_slider_images` (`id`, `name`, `created_by`, `created_date`, `modified_by`, `modified_date`, `status`, `views`) VALUES
(1, 'mountains1.jpg', 1, '2017-12-29 14:24:39', 0, '0000-00-00 00:00:00', 'active', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_subcategory`
--

CREATE TABLE `tbl_subcategory` (
  `subcat_id` bigint(20) NOT NULL,
  `parent_category_id` int(11) NOT NULL,
  `subcategory_name` varchar(255) DEFAULT NULL,
  `image` varchar(500) NOT NULL,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `modified_date` datetime DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_subcategory`
--

INSERT INTO `tbl_subcategory` (`subcat_id`, `parent_category_id`, `subcategory_name`, `image`, `created_by`, `modified_by`, `modified_date`, `created_date`, `status`) VALUES
(1, 1, 'Jeans', 'spring2_m_clothing_vd_set1_4__v534219377_.jpg', 1, 1, '2017-04-13 21:08:37', '2017-04-13 21:06:54', '0');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_wishlist`
--

CREATE TABLE `tbl_wishlist` (
  `wish_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `product_price` double NOT NULL,
  `created_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_wishlist`
--

INSERT INTO `tbl_wishlist` (`wish_id`, `user_id`, `product_id`, `product_price`, `created_date`) VALUES
(1, 1, 7, 725, '2017-04-13');

-- --------------------------------------------------------

--
-- Table structure for table `user_detail`
--

CREATE TABLE `user_detail` (
  `id` int(11) NOT NULL,
  `firstname` varchar(255) NOT NULL,
  `middlename` varchar(255) NOT NULL,
  `lastname` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `profile` varchar(255) NOT NULL,
  `mobile` varchar(255) NOT NULL,
  `whatsapp` varchar(255) NOT NULL,
  `room_no` varchar(255) NOT NULL,
  `floor` varchar(255) NOT NULL,
  `building` varchar(255) NOT NULL,
  `street` varchar(255) NOT NULL,
  `area` varchar(255) NOT NULL,
  `city` varchar(255) NOT NULL,
  `pincode` varchar(255) NOT NULL,
  `state` varchar(255) NOT NULL,
  `country` varchar(255) NOT NULL,
  `secondary_address` text NOT NULL,
  `created_date` datetime NOT NULL,
  `status` varchar(255) NOT NULL,
  `created_by` varchar(255) NOT NULL,
  `is_Admin` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_detail`
--

INSERT INTO `user_detail` (`id`, `firstname`, `middlename`, `lastname`, `email`, `password`, `profile`, `mobile`, `whatsapp`, `room_no`, `floor`, `building`, `street`, `area`, `city`, `pincode`, `state`, `country`, `secondary_address`, `created_date`, `status`, `created_by`, `is_Admin`) VALUES
(1, 'Admin', '', 'Admin', 'admin@gmail.com', '123456', '', '9925252525', '', '', '', '', '', '', '', '', '', '', '', '2016-11-04 17:29:56', '0', '1', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_cart`
--
ALTER TABLE `tbl_cart`
  ADD PRIMARY KEY (`cart_id`);

--
-- Indexes for table `tbl_cart_product`
--
ALTER TABLE `tbl_cart_product`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_category`
--
ALTER TABLE `tbl_category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_checkout`
--
ALTER TABLE `tbl_checkout`
  ADD PRIMARY KEY (`checkout_id`);

--
-- Indexes for table `tbl_color`
--
ALTER TABLE `tbl_color`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_contact`
--
ALTER TABLE `tbl_contact`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_customers`
--
ALTER TABLE `tbl_customers`
  ADD PRIMARY KEY (`customer_id`);

--
-- Indexes for table `tbl_products`
--
ALTER TABLE `tbl_products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_sales`
--
ALTER TABLE `tbl_sales`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_sales_detail`
--
ALTER TABLE `tbl_sales_detail`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_size`
--
ALTER TABLE `tbl_size`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_slider_images`
--
ALTER TABLE `tbl_slider_images`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_subcategory`
--
ALTER TABLE `tbl_subcategory`
  ADD PRIMARY KEY (`subcat_id`);

--
-- Indexes for table `tbl_wishlist`
--
ALTER TABLE `tbl_wishlist`
  ADD PRIMARY KEY (`wish_id`);

--
-- Indexes for table `user_detail`
--
ALTER TABLE `user_detail`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_cart`
--
ALTER TABLE `tbl_cart`
  MODIFY `cart_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
--
-- AUTO_INCREMENT for table `tbl_cart_product`
--
ALTER TABLE `tbl_cart_product`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT for table `tbl_category`
--
ALTER TABLE `tbl_category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `tbl_checkout`
--
ALTER TABLE `tbl_checkout`
  MODIFY `checkout_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `tbl_color`
--
ALTER TABLE `tbl_color`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `tbl_contact`
--
ALTER TABLE `tbl_contact`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `tbl_customers`
--
ALTER TABLE `tbl_customers`
  MODIFY `customer_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `tbl_products`
--
ALTER TABLE `tbl_products`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
--
-- AUTO_INCREMENT for table `tbl_sales`
--
ALTER TABLE `tbl_sales`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `tbl_sales_detail`
--
ALTER TABLE `tbl_sales_detail`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `tbl_size`
--
ALTER TABLE `tbl_size`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `tbl_slider_images`
--
ALTER TABLE `tbl_slider_images`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `tbl_subcategory`
--
ALTER TABLE `tbl_subcategory`
  MODIFY `subcat_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `tbl_wishlist`
--
ALTER TABLE `tbl_wishlist`
  MODIFY `wish_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `user_detail`
--
ALTER TABLE `user_detail`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
