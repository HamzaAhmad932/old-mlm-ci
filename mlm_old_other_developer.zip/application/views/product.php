<!DOCTYPE HTML>
<html>
<head>
<link href="<?=base_url();?>css/bootstrap.css" rel="stylesheet" type="text/css" media="all"/>
<link href="<?=base_url();?>css/style.css" rel="stylesheet" type="text/css" media="all" />
<link href="<?=base_url();?>css/owl.carousel.css" rel="stylesheet">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<script src="<?=base_url();?>js/jquery.min.js"></script>
<script type="text/javascript" src="<?=base_url();?>js/bootstrap-3.1.1.min.js"></script>
	<!-- cart -->
		<script src="<?=base_url();?>js/simpleCart.min.js"> </script>
	<!-- cart -->
<!-- the jScrollPane script -->
<script type="text/javascript" src="<?=base_url();?>js/jquery.jscrollpane.min.js"></script>
		
<!-- //the jScrollPane script -->
<script type="text/javascript" src="<?=base_url();?>js/jquery.jscrollpane.min.js"></script>
		<script type="text/javascript" id="sourcecode">
			$(function()
			{
				$('.scroll-pane').jScrollPane();
			});
		</script>
<link href="<?=base_url();?>css/form.css" rel="stylesheet" type="text/css" media="all" />
		<!-- the mousewheel plugin -->
    <script type="text/javascript" src="<?=base_url();?>js/jquery.mousewheel.js"></script>
    <style>
    .active1
    {
        border: 2px solid #0000ff;
    }
    .modal-header {
    border-bottom: 0px solid #e5e5e5;
    min-height: 16.4286px;
    padding: 15px;
}
    </style>
</head>
<body>
	<!--header-->
		<?php require_once 'header_pro.php';?>
			<!--header-->
			<div class="content">
	<div class="product-model">	 
	 <div class="container">
		<h2><?php
		$cat_IDx = $this->uri->segment(2);
		$cat_name = $this->db->get_where('tbl_category',array('id'=>$cat_IDx))->result_array();
		//print_r($cat_name);
		if(!empty($cat_name[0]))
		{
		    print_r($cat_name[0]['category_name']);
		}
             foreach ($category_list as $title)
                { 
                    
                    if($title->category_name == $category_list)
                    { ?>
            
                    <span style="text-transform: capitalize;">< ?=$title->category_name; ?></span>
		<div class="clearfix"> </div>
                   <?php }
                }?></h2>			
		 <div class="col-md-9 product-model-sec">
                     <?php
                     if(!empty($productlist))
                                    {
                                        foreach ($productlist as $post)
                                        {
                                            $id = $post->id;
                                            $name = $post->product_name;
                                            $description = $post->product_description;
                                            $price = $post->product_price;
                                            $image = $post->product_image;
                                        ?>
                     <!--new loop=======================================================-->
                     <div class="col-xs-6 col-sm-4 col-md-4">
		    <div class="product">
			    <div class="product_inside">
				    <div class="image-box">
					    <a href="<?=base_url();?>ProductDetail/<?=$post->id;?>">
					        <img src="<?=base_url();?>/upload/product/<?=$post->id;?>/<?=$post->product_image;?>" alt="<?=$post->product_name;?>"/>
					    </a>
				    </div>
			    <h2 class="title"><a href="<?=base_url();?>ProductDetail/<?=$post->id;?>"><?=$post->product_name;?></a></h2>
					<div class="price"><span><span class=money>Rs. <?=$post->product_price;?></span></span><span class="old-price hide"></span></div>
			    	<div class="description"><?=$post->product_description;?></div>
			    	<span class="money">PV:  <?=$post->pv;?> | BV:  <?=$post->bv;?></span>
			    	<div class="product_inside_hover">
				    <div class="product_inside_info">
				    </div>
			    		 
			    		<?php  echo "<form action='".base_url()."cart/add' method='post' name='productformcart' id='addcartform'>
                                                                                    <input type='hidden' name='id'  value=".$post->id.">
                                                                                    <input type='hidden' name='name'  value=".$post->product_name.">
                                                                                    <input type='hidden' name='price' value=".$post->product_price.">
                                                                                    <input type='hidden' name='image' value=".$post->product_image.">
                                                                                     <input min='1' type='number' id='quantity' name='qty' value='1' class='form-control input-small' style='width:60px;display:none;'>
                                                                                     
                                                                                    <button type='submit'  class='btn btn-product_addtocart' name='action'><span class='icon icon-shopping_basket'></span> ADD TO CART</button>
                                                                                </form>"; ?>
			      	</div>
			    	</div>
		    </div>
		</div>
		<!-- end loop===================================================================-->
					  
                                    <?php } }?>
                     <div class="col-md-12">
                            <div style="text-align: right;"> 
                        <ul class="pagination" style="">
                             <?php foreach ($linked as $link) {
                                 ?>
                                  <li><?=$link?></li>
                            <?php } ?>
                        </ul>
                    </div>
                     </div>
				</div>	
                
			<div class="rsidebar span_1_of_left">
				 <section  class="sky-form">
					 <div class="product_right">
						 <h4 class="m_2"><span class="glyphicon glyphicon-minus" aria-hidden="true"></span>Categories</h4>
                                                  <?php
                                                foreach ($category_list as $category)
                                                {
                                                ?>
						 <div class="tab1">
							 <ul class="place">								
                                                             <li class="sort" style="text-transform: capitalize;"><a href="<?=base_url();?>ProductList/<?=$category->id;?>"><?=$category->category_name?></li>
                                                                <div class="clearfix"> </div>
							  </ul>
                                	      </div>
                                                <?php }?>
                                         </div>
				 </section>
				 
							 
				   
				 <section  class="sky-form">
						<!--<h4><span class="glyphicon glyphicon-minus" aria-hidden="true"></span>Price</h4>-->
							<ul class="dropdown-menu1">
                                                            <li><a>
								<div id="slider-range"></div>							
								<!--<input type="text" id="amount" style="border: 0; font-weight: NORMAL;   font-family: 'Dosis-Regular';" />-->
                                                                </a></li>			
						  </ul>
				   </section>
				   <!---->
					 <script type="text/javascript" src="<?=base_url();?>js/jquery-ui.min.js"></script>
					 <!--<link rel="stylesheet" type="text/css" href="<?=base_url();?>css/jquery-ui.css">-->
					
  
				   
							   
			 </div>				 
	      </div>
		</div>
</div>
                        <div class="modal fade" id="header-modal" aria-hidden="true"></div>
	<!--footer-->
		<?php require_once 'footer_pro.php';?>
	<!--footer-->
		
        <script type="text/javascript">
            
		$(document).ready(function() {
                    
            $("#header-modal").delegate("#addcartform","submit",function(e){       
                    var color = document.forms["productformcart"]["color"].value;
                    if (color == null || color == "") {
                            alert("Color must be Selected. Click for select.");
                            return false;
                    }

                    var size = document.forms["productformcart"]["size"].value;
                    if (size == null || size == "") {
                            alert("Size must be Selected. Click for select.");
                            return false;
                    }
            });
                    
                     
                         
                   
                     $("#header-modal").delegate(".data_values","click",function(e){
                        var id = $(this).attr('id');
                        $('.data_values').removeClass('active1');
                        $("#"+id).addClass('active1');
                        $("#colorProduct").val(id.slice(1));
                    });
                     $("#header-modal").delegate(".data_values_size","click",function(e){
                        var id = $(this).attr('id');
                        $('.data_values_size').removeClass('active1');
                        $("#"+id).addClass('active1');
                        $("#sizeProduct").val(id.slice(4));
                    });

                    
                    $('.quicklook').click(function() {
                        var product_id = $(this).attr('id');
                        $.ajax({
                                type: "POST",
                                url: "<?=base_url();?>product/SingleProuctDetail",
                                data: {product_id: product_id},
                                dataType: "json",
                                success: function(data) {
                                     $("#header-modal").html(data.success);
                                      $('#header-modal').modal('show');  
                                }
                               
                        });
                });
        });
	</script>
</body>
</html>
