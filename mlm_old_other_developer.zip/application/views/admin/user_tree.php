<!DOCTYPE html>
<html class="no-focus">
    <head>
        <meta charset="utf-8">
        <title>Customer Tree - Dashboard</title>
        
        <link rel="shortcut icon" href="assets/img/favicons/favicon.png">

        <!-- Web fonts -->
        <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400italic,600,700%7COpen+Sans:300,400,400italic,600,700">
        <link rel="stylesheet" href="<?= base_url();?>assets/js/plugins/datatables/jquery.dataTables.min.css">
        <link rel="stylesheet" href="<?= base_url();?>assets/css/bootstrap.min.css">
        <link rel="stylesheet" id="css-main" href="<?= base_url();?>assets/css/oneui.css">

    </head>
    <body>
            <div id="page-container" class="side-scroll header-navbar-fixed">
         
           <?php //  require_once ('sidebar.php');?>
         <?php      require_once('header.php'); ?>

            <!-- Main Container -->
            <main id="main-container" style="background: #ffffff;">
                <!-- Page Header -->
                <div class="content bg-image overflow-hidden" style="background-image: url('<?php echo base_url(); ?>/assets/img/photos/photo3@2x.jpg');">
                    <div class="push-50-t push-15">
                        <h1 class="h2 text-white animated zoomIn">Dashboard</h1>
                        <h2 class="h5 text-white-op animated zoomIn">Welcome Administrator - Level Settings</h2>
                    </div>
                </div>
                <!-- END Page Header -->

              
            <!-- Page Content -->
             <div class="content row">
             
                    <div class="block">
                        
                      
                    <div class="col-md-12" style="padding-top: 20px;"></div>
                   
                    </div>
                 

                 
                    
                 

                 
                </div>
                    <!-- Page Header -->
                <div class="content row">
             
                    <div class="block">
                        
                      
                    <div class="col-md-12" style="padding-top: 20px;"></div>
                   
                        <!--treeUser -->
                                  <!--tree code-->
                    
<div class="tree">
  <ul>
    <li>
        <?php
        $offsetID = $this->uri->segment(2);
        $rangeID  = $this->uri->segment(3);
        $ParentData = $this->db->get_where('tbl_customers',array('customer_id'=>$offsetID))->result_array();
        $this->db->limit(14);
        $C1Data = $this->db->get_where('tbl_refferal',array('refferral_id'=>$_SESSION['customerTreeID'],'id >'=> $rangeID))->result_array();
           //$C1personalData = $this->db->get_where('tbl_customers',array('customer_id'=>$C1Data[]['customerTreeID']))->result_array();
           ?>
            
      <a href="#"><?=$ParentData[0]['first_name']."(".$ParentData[0]['first_name'].")";?></a>
      <ul>
          <?php if(!empty($C1Data))
          {
          ?>
        <li>
          
                   <?php 
                    if(!empty($C1Data[0]['customer_id']))
                  {
                      ?>
                       <a href="<?=base_url().'customer-tree/'.$C1Data[0]['customer_id'].'/'.$C1Data[0]['id'];?>">
                      <?php
              $C1personalData = $this->db->get_where('tbl_customers',array('customer_id'=>$C1Data[0]['customer_id']))->result_array(); ?>
           <?php if(!empty($C1personalData)) { echo $C1personalData[0]['first_name'];  } ?></a> <?php } ?>
          <ul>
            <li>
                <?php
                if(!empty($C1Data[2]['customer_id']))
                  {
                
                ?>
              <a href="<?=base_url().'customer-tree/'.$C1Data[2]['customer_id'].'/'.$C1Data[2]['id'];?>">
                   <?php 
                    
              $C1personalData = $this->db->get_where('tbl_customers',array('customer_id'=>$C1Data[2]['customer_id']))->result_array(); ?>
           <?php if(!empty($C1personalData)) { echo $C1personalData[0]['first_name']; }  ?></a><?php } ?>
              <ul>
                <li>
                    <?php
                    if(!empty($C1Data[6]['customer_id']))
                    {
                    ?>
                  <a href="<?=base_url().'customer-tree/'.$C1Data[6]['customer_id'].'/'.$C1Data[6]['id'];?>">
                   <?php 
                    
              $C1personalData = $this->db->get_where('tbl_customers',array('customer_id'=>$C1Data[6]['customer_id']))->result_array(); ?>
           <?php if(!empty($C1personalData)) { echo $C1personalData[0]['first_name']; } ?></a><?php } ?>
                </li>
                <li>
                    <?php
                    if(!empty($C1Data[7]['customer_id']))
                    {
                    ?>
                  <a href="<?=base_url().'customer-tree/'.$C1Data[7]['customer_id'].'/'.$C1Data[7]['id'];?>">
                   <?php 
                    
              $C1personalData = $this->db->get_where('tbl_customers',array('customer_id'=>$C1Data[7]['customer_id']))->result_array(); ?>
           <?php if(!empty($C1personalData)) { echo $C1personalData[0]['first_name']; }  ?></a><?php } ?>
                </li>
              </ul>
            </li>
            <li>
                <?php 
                if(!empty($C1Data[3]['customer_id']))
                  {
                ?>
               <a href="<?=base_url().'customer-tree/'.$C1Data[3]['customer_id'].'/'.$C1Data[3]['id'];?>">
                   <?php 
                    
              $C1personalData = $this->db->get_where('tbl_customers',array('customer_id'=>$C1Data[3]['customer_id']))->result_array(); ?>
           <?php if(!empty($C1personalData)) { echo $C1personalData[0]['first_name']; }  ?></a><?php } ?>
              <ul>
                <li>
                    <?php 
                     if(!empty($C1Data[8]['customer_id']))
                        {
                    ?>
                    <a href="<?=base_url().'customer-tree/'.$C1Data[8]['customer_id'].'/'.$C1Data[8]['id'];?>">
                   <?php 
                   
              $C1personalData = $this->db->get_where('tbl_customers',array('customer_id'=>$C1Data[8]['customer_id']))->result_array(); ?>
           <?php if(!empty($C1personalData)) { echo $C1personalData[0]['first_name']; }  ?></a><?php } ?>
                </li>
                <li>
                    <?php 
                    if(!empty($C1Data[9]['customer_id']))
                    {
                    ?>
                  <a href="<?=base_url().'customer-tree/'.$C1Data[9]['customer_id'].'/'.$C1Data[9]['id'];?>"> <?php 
                   
              $C1personalData = $this->db->get_where('tbl_customers',array('customer_id'=>$C1Data[9]['customer_id']))->result_array(); ?>
           <?php if(!empty($C1personalData)) { echo $C1personalData[0]['first_name']; }  ?></a> <?php } ?>
                </li>
              </ul>
            </li>
          </ul>
        </li>
        <?php } ?>
        <li>
            <?php
                if(!empty($C1Data[1]['customer_id']))
                  {
            ?>
          <a href="<?=base_url().'customer-tree/'.$C1Data[1]['customer_id'].'/'.$C1Data[1]['id'];?>">
                   <?php 
                
              $C1personalData = $this->db->get_where('tbl_customers',array('customer_id'=>$C1Data[1]['customer_id']))->result_array(); ?>
           <?php if(!empty($C1personalData)) { echo $C1personalData[0]['first_name']; }  ?></a> <?php } ?>
          <ul>
            
            <li>
                <?php 
                 if(!empty($C1Data[4]['customer_id']))
                  {
                ?>
                <a href="<?=base_url().'customer-tree/'.$C1Data[4]['customer_id'].'/'.$C1Data[4]['id'];?>">
                   <?php 
                   
              $C1personalData = $this->db->get_where('tbl_customers',array('customer_id'=>$C1Data[4]['customer_id']))->result_array(); ?>
           <?php if(!empty($C1personalData)) { echo $C1personalData[0]['first_name']; }  ?></a><?php } ?>
              <ul>
                <li>
                    <?php 
                    if(!empty($C1Data[10]['customer_id']))
                  {
                    ?>
                  <a href="<?=base_url().'customer-tree/'.$C1Data[10]['customer_id'].'/'.$C1Data[10]['id'];?>">
                   <?php 
                    
              $C1personalData = $this->db->get_where('tbl_customers',array('customer_id'=>$C1Data[10]['customer_id']))->result_array(); ?>
           <?php if(!empty($C1personalData)) { echo $C1personalData[0]['first_name']; }  ?></a><?php } ?>
                </li>
                <li>
                    <?php 
                    if(!empty($C1Data[11]['customer_id']))
                  {
                    ?>
                  <a href="<?=base_url().'customer-tree/'.$C1Data[11]['customer_id'].'/'.$C1Data[11]['id'];?>">
                   <?php 
                    
              $C1personalData = $this->db->get_where('tbl_customers',array('customer_id'=>$C1Data[11]['customer_id']))->result_array(); ?>
           <?php if(!empty($C1personalData)) { echo $C1personalData[0]['first_name']; }  ?></a><?php } ?>
                </li>
              </ul>
            </li>
            <li>
                <?php
                if(!empty($C1Data[5]['customer_id']))
                  {
                ?>
              <a href="<?=base_url().'customer-tree/'.$C1Data[5]['customer_id'].'/'.$C1Data[5]['id'];?>">
                   <?php 
                    
              $C1personalData = $this->db->get_where('tbl_customers',array('customer_id'=>$C1Data[5]['customer_id']))->result_array(); ?>
           <?php if(!empty($C1personalData)) { echo $C1personalData[0]['first_name']; }  ?></a><?php } ?>
              <ul>
                <li>
                    <?php
                     if(!empty($C1Data[12]['customer_id']))
                    {
                    ?>
                  <a href="<?=base_url().'customer-tree/'.$C1Data[12]['customer_id'].'/'.$C1Data[12]['id'];?>"> <?php 
                 
              $C1personalData = $this->db->get_where('tbl_customers',array('customer_id'=>$C1Data[12]['id']))->result_array(); ?>
          <?php if(!empty($C1personalData)) { echo $C1personalData[0]['first_name']; } ?></a><?php } ?>
                </li>
                <li>
                    <?php 
                     if(!empty($C1Data[13]['customer_id']))
                  {
                    ?>
                 <a href="<?=base_url().'customer-tree/'.$C1Data[13]['customer_id'].'/'.$C1Data[13]['id'];?>">
                   <?php 
                   
              $C1personalData = $this->db->get_where('tbl_customers',array('customer_id'=>$C1Data[7]['customer_id']))->result_array(); ?>
           <?php if(!empty($C1personalData)) { echo $C1personalData[0]['first_name']; }  ?></a> <?php } ?>
                </li>
              </ul>
            </li>
             
          </ul>
        </li>
      </ul>
    </li>
  </ul>
</div>
<style type="text/css">
  /*Now the CSS*/
* {margin: 0; padding: 0;}

 .tree ul {
  padding-top: 20px; position: relative!important;
  
  transition: all 0.5s!important;
  -webkit-transition: all 0.5s!important;
  -moz-transition: all 0.5s!important;
}

 .tree li {
  float: left!important; text-align: center!important;
  list-style-type: none!important;
  position: relative!important;
  padding: 20px 5px 0 5px!important;
  transition: all 0.5s!important;
  -webkit-transition: all 0.5s!important;
  -moz-transition: all 0.5s!important;
}

/*We will use ::before and ::after to draw the connectors*/

 .tree li::before, .tree li::after{
  content: ''!important;
  position: absolute!important; top: 0!important; right: 50%!important;
  border-top: 1px solid #ccc!important;
  width: 50%!important; height: 20px!important;
}
 .tree li::after{
  right: auto!important; left: 50%!important;
  border-left: 1px solid #ccc!important;
}

/*We need to remove left-right connectors from elements without 
any siblings*/
 .tree li:only-child::after, .tree li:only-child::before {
  display: none!important;
}

/*Remove space from the top of single children*/
 .tree li:only-child{ padding-top: 0!important;}

/*Remove left connector from first child and 
right connector from last child*/
 .tree li:first-child::before, .tree li:last-child::after{
  border: 0 none!important;
}
/*Adding back the vertical connector to the last nodes*/
 .tree li:last-child::before{
  border-right: 1px solid #ccc!important;
  border-radius: 0 5px 0 0!important;
  -webkit-border-radius: 0 5px 0 0!important;
  -moz-border-radius: 0 5px 0 0!important;
}
 .tree li:first-child::after{
  border-radius: 5px 0 0 0!important;
  -webkit-border-radius: 5px 0 0 0!important;
  -moz-border-radius: 5px 0 0 0!important;
}

/*Time to add downward connectors from parents*/
 .tree ul ul::before{
  content: ''!important;
  position: absolute; top: 0; left: 50%!important;
  border-left: 1px solid #ccc!important;
  width: 0; height: 20px!important;
}

 .tree li a{
  border: 1px solid #ccc!important;
  padding: 5px 10px!important;
  text-decoration: none!important;
  color: #666!important;
  font-family: arial, verdana, tahoma!important;
  font-size: 11px!important;
  display: inline-block!important;
  
  border-radius: 5px!important;
  -webkit-border-radius: 5px!important;
  -moz-border-radius: 5px!important;
  
  transition: all 0.5s!important;
  -webkit-transition: all 0.5s!important;
  -moz-transition: all 0.5s!important;
}

/*Time for some hover effects*/
/*We will apply the hover effect the the lineage of the element also*/
 .tree li a:hover, .tree li a:hover+ul li a {
  background: #c8e4f8; color: #000; border: 1px solid #94a0b4;
}
/*Connector styles on hover*/
 .tree li a:hover+ul li::after, 
 .tree li a:hover+ul li::before, 
 .tree li a:hover+ul::before, 
 .tree li a:hover+ul ul::before{
  border-color:  #94a0b4;
}

/*Thats all. I hope you enjoyed it.
Thanks :)*/
</style>
                  <!--tree code-->
                        
                        
                        
                        
                        
                        
                        <!--treeUser End-->
                    </div>
                 

                 
                    
                 

                 
                </div>
                    <!-- Extra Modal Options -->
                </div>
                <!-- END Page Content -->
            </main>
            <!-- END Main Container -->
     <div class="modal fade" id="header-modal" aria-hidden="true"></div>
            <!-- Footer -->
            <?php require_once ('footer.php');?>
            <!-- END Footer -->
        </div>
        <!-- END Page Container
          <script src="<?= base_url();?>assets/js/core/jquery.min.js"></script>
        <script src="<?= base_url();?>assets/js/core/bootstrap.min.js"></script>
        <script src="<?= base_url();?>assets/js/core/jquery.slimscroll.min.js"></script>
        <script src="<?= base_url();?>assets/js/core/jquery.scrollLock.min.js"></script>
        <script src="<?= base_url();?>assets/js/core/jquery.appear.min.js"></script>
        <script src="<?= base_url();?>assets/js/core/jquery.countTo.min.js"></script>
        <script src="<?= base_url();?>assets/js/core/jquery.placeholder.min.js"></script>
        <script src="<?= base_url();?>assets/js/core/js.cookie.min.js"></script>
        <script src="<?= base_url();?>assets/js/app.js"></script>

        <!-- Page JS Plugins --
        <script src="<?= base_url();?>assets/js/plugins/datatables/jquery.dataTables.min.js"></script>

        <!-- Page JS Code --
        <script src="<?= base_url();?>assets/js/pages/base_tables_datatables.js"></script>
        
        
        <script src="<?= base_url();?>assets/js/plugins/bootstrap-datepicker/bootstrap-datepicker.min.js"></script>
        <script src="<?= base_url();?>assets/js/plugins/bootstrap-datetimepicker/moment.min.js"></script>
        <script src="<?= base_url();?>assets/js/plugins/bootstrap-datetimepicker/bootstrap-datetimepicker.min.js"></script>
-->
    </body>
</html>