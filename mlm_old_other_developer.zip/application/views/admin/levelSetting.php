<!DOCTYPE html>
<html class="no-focus">
    <head>
        <meta charset="utf-8">
        <title>Comission Setup - Dashboard</title>
        <meta name="description" content="OneUI - Admin Dashboard Template &amp; UI Framework created by pixelcave and published on Themeforest">
        <meta name="author" content="pixelcave">
        <meta name="robots" content="noindex, nofollow">
        <meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1.0">
        <link rel="shortcut icon" href="assets/img/favicons/favicon.png">

        <!-- Web fonts -->
        <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400italic,600,700%7COpen+Sans:300,400,400italic,600,700">
        <link rel="stylesheet" href="<?= base_url();?>assets/js/plugins/datatables/jquery.dataTables.min.css">
        <link rel="stylesheet" href="<?= base_url();?>assets/css/bootstrap.min.css">
        <link rel="stylesheet" id="css-main" href="<?= base_url();?>assets/css/oneui.css">

    </head>
    <body>
            <div id="page-container" class="side-scroll header-navbar-fixed">
         
           <?php //  require_once ('sidebar.php');?>
         <?php      require_once('header.php'); ?>

            <!-- Main Container -->
            <main id="main-container" style="background: #ffffff;">
                <!-- Page Header -->
                <div class="content bg-image overflow-hidden" style="background-image: url('<?php echo base_url(); ?>/assets/img/photos/photo3@2x.jpg');">
                    <div class="push-50-t push-15">
                        <h1 class="h2 text-white animated zoomIn">Dashboard</h1>
                        <h2 class="h5 text-white-op animated zoomIn">Welcome Administrator - Level Settings</h2>
                    </div>
                </div>
                <!-- END Page Header -->

              
            <!-- Page Content -->
             <div class="content row">
             
                    <div class="block">
                        
                      
                    <div class="col-md-12" style="padding-top: 20px;"></div>
                    <div class="block-content">
                        <form action="<?=base_url();?>admin/dashboard/updateDefaultID" method="post">
                            <table class="table table-bordered table-striped xjs-dataTable-full">
                                <thead>
                                    <tr>
                                        <th>Deafult ID</th>
                                        
                                         
                                    </tr>
                                </thead>
                                <tbody>
                                    
                                    <?php 
                                    $cdefID = $this->db->get('tbl_default_id')->result_array();
                                    for($x=0; $x < count($cdefID); $x++)
                                    {
                                    ?> 
                                    <tr>
                                        <td>
                                        <input type="text" value="<?=$cdefID[$x]['default_id'];?>" name="defID">
                                        </td>
                                    </tr>
                                    <?php } ?>
                                    
                                </tbody>
                            </table>
                            <button type="submit" class="btn btn-primary" style="float:right;">Update Now</button>
                                    </form>
                        </div>
                    </div>
                 

                 
                    
                 

                 
                </div>
                    <!-- Page Header -->
                <div class="content row">
             
                    <div class="block">
                        
                      
                    <div class="col-md-12" style="padding-top: 20px;"></div>
                    <div class="block-content">
                        <form action="<?=base_url();?>admin/dashboard/updateComission" method="post">
                            <table class="table table-bordered table-striped xjs-dataTable-full">
                                <thead>
                                    <tr>
                                        <th>Level Number</th>
                                        <th>Refferals For level</th>
                                        <th>Package</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    
                                    <?php 
                                    //$comisionSettings = $this->db->get('tbl_comission_dist')->result_array();
                                    for($x=0; $x < count($levelCriterion); $x++)
                                    {
                                    ?> 
                                   <tr>
                                        <td><?=$levelCriterion[$x]['level_standard'];?><input type="hidden" value="<?=$levelCriterion[$x]['level_standard'];?>" name="level_standard[]"></td>
                                        <td><input type="text" value="<?=$levelCriterion[$x]['ref_per_level'];?>" name="ref_per_level[]"></td>
                                        <td><input type="text" value="<?=$levelCriterion[$x]['name_pkg'];?>" name="name_pkg[]"></td>
                                    </tr>
                                    <?php } ?>
                                    
                                </tbody>
                            </table>
                            <button type="submit" class="btn btn-primary" style="float:right;">Update Now</button>
                                    </form>
                        </div>
                    </div>
                 

                 
                    
                 

                 
                </div>
                    <!-- Extra Modal Options -->
                </div>
                <!-- END Page Content -->
            </main>
            <!-- END Main Container -->
     <div class="modal fade" id="header-modal" aria-hidden="true"></div>
            <!-- Footer -->
            <?php require_once ('footer.php');?>
            <!-- END Footer -->
        </div>
        <!-- END Page Container -->

          <script src="<?= base_url();?>assets/js/core/jquery.min.js"></script>
        <script src="<?= base_url();?>assets/js/core/bootstrap.min.js"></script>
        <script src="<?= base_url();?>assets/js/core/jquery.slimscroll.min.js"></script>
        <script src="<?= base_url();?>assets/js/core/jquery.scrollLock.min.js"></script>
        <script src="<?= base_url();?>assets/js/core/jquery.appear.min.js"></script>
        <script src="<?= base_url();?>assets/js/core/jquery.countTo.min.js"></script>
        <script src="<?= base_url();?>assets/js/core/jquery.placeholder.min.js"></script>
        <script src="<?= base_url();?>assets/js/core/js.cookie.min.js"></script>
        <script src="<?= base_url();?>assets/js/app.js"></script>

        <!-- Page JS Plugins -->
        <script src="<?= base_url();?>assets/js/plugins/datatables/jquery.dataTables.min.js"></script>

        <!-- Page JS Code -->
        <script src="<?= base_url();?>assets/js/pages/base_tables_datatables.js"></script>
        
        
        <script src="<?= base_url();?>assets/js/plugins/bootstrap-datepicker/bootstrap-datepicker.min.js"></script>
        <script src="<?= base_url();?>assets/js/plugins/bootstrap-datetimepicker/moment.min.js"></script>
        <script src="<?= base_url();?>assets/js/plugins/bootstrap-datetimepicker/bootstrap-datetimepicker.min.js"></script>

    </body>
</html>