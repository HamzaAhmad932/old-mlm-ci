
<footer id="page-footer" class="content-mini content-mini-full font-s12 bg-gray-lighter clearfix">
                <div class="pull-right">
                    &copy; 2018 All rights reserved.
                </div>
 
</footer>