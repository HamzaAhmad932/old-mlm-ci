<!doctype html>
<!--[if lt IE 7]><html class="no-js lt-ie9 lt-ie8 lt-ie7" lang="en"> <![endif]-->
<!--[if IE 7]><html class="no-js lt-ie9 lt-ie8" lang="en"> <![endif]-->
<!--[if IE 8]><html class="no-js lt-ie9" lang="en"> <![endif]-->
<!--[if IE 9 ]><html class="ie9 no-js"> <![endif]-->
<!--[if (gt IE 9)|!(IE)]><!--> <html class="no-js"> <!--<![endif]-->
<meta http-equiv="content-type" content="text/html;charset=utf-8" />
<head>
	<!-- v1.0.0 -->
	<!-- Basic page needs ================================================== -->
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"><link rel="shortcut icon" href="<?=base_url();?>fassets/favicon760d.png" type="image/x-icon" /><!-- Title and description ================================================== -->
	<title>E- Com Xoftmade</title><meta name="description" content="mlm by faizan"><meta name="timezone" content="US/Central">
<!-- Social meta ================================================== -->
	<meta property="og:type" content="website">
	<meta property="og:title" content="E- Com Xoftmade">
	<meta property="og:url" content="">
	<meta property="og:description" content="MLM ">
	<meta property="og:site_name" content="E- Com Xoftmade">
	<meta name="twitter:card" content="E- Com Xoftmade">
	<meta name="twitter:title" content="E- Com Xoftmade">
    <meta name="twitter:description" content="E- Com Xoftmade">  
<!-- Helpers ================================================== -->
    <link rel="canonical" href="index.html">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="theme-color" content="">
<!-- CSS ================================================== -->
    <link href="https://fonts.googleapis.com/css?family=Poppins:100,200,300,400,500,600,700,800,900" rel="stylesheet">
    <link href="<?=base_url();?>fassets/bootstrap760d.css" rel="stylesheet" type="text/css" media="all" />
	<link href="<?=base_url();?>fassets/fontstyle760d.css" rel="stylesheet" type="text/css" media="all" />
	<link href="<?=base_url();?>fassets/slick.min760d.css" rel="stylesheet" type="text/css" media="all" />
	<link href="<?=base_url();?>fassets/settings.min760d.css" rel="stylesheet" type="text/css" media="all" />
	<link href="<?=base_url();?>fassets/style.scss760d.css" rel="stylesheet" type="text/css" media="all" />
<!-- JS ===================================================-->
	<script src="<?=base_url();?>fassets/jquery-2.1.4.min760d.js" type="text/javascript"></script>
    
<!-- Header hook for plugins ================================================== -->
	<link rel="stylesheet" media="screen" href="<?=base_url();?>fassets/files/1/1408/4802/t/3/compiled_assets/styles760d.css" />
	<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
 
</head>
<body>
 
  <script>
    $('.btn-close-js').click(function(e){
      e.preventDefault()
      $('.header-top-line').remove();
    });
  </script>
<div id="shopify-section-header" class="shopify-section">
 
<?php require_once 'header_pro.php';?>
  
</div>
<div id="pageContent"><!-- BEGIN content_for_index --><div id="shopify-section-1495650331083" class="shopify-section index-section"><div class="container-fluid offset-0" data-sectionname="index_revolution">
  <div class="row">
    
    <div class="slider-revolution revolution-default" data-speed="16000">
      <div class="tp-banner-container">
        <div class="tp-banner revolution">
          <ul>
                                <?php
                                    foreach ($slider as $value)
                                    {
                                ?>
                                    
                                    
                                  
                                            
                                    
                                    
            
            <li data-thumb="//cdn.shopify.com/s/files/1/1408/4802/files/index01-slide-1_x1024.jpg?v=1495896705" data-transition="fade" data-slotamount="1" data-masterspeed="1000" data-saveperformance="off"  data-title="Slide">
              
              
              
              <img src="<?=base_url();?>upload/slider/<?=$value->id?>/<?=$value->name;?>" alt="" data-bgposition="center center" data-bgfit="cover" data-bgrepeat="no-repeat" >
              
              
              
              
              
              
              <div class="tp-caption tp-resizeme lfb stb text-center"
                   data-x="center"
                   data-y="center"
                   data-hoffset="0"
                   data-voffset="-20"
                   data-speed="600"
                   data-start="900"
                   data-easing="Power4.easeOut"
                   data-endeasing="Power4.easeIn"
                   data-responsive_offset="on"
                   style="z-index: 2;">
                <!--div class="tp-caption1-wd-1" style="color:#ffffff">Our Experience Gives us the Ability to</div>
                <div class="tp-caption1-wd-2" style="color:#ffffff">Create Stunning<br>Webstore</div
                
                <div class="tp-caption1-wd-3"><a href="#" class="btn btn-lg" style="color:#ffffff; background:rgb(254, 65, 53);" data-c="#ffffff" data-ac="#ffffff" data-bgc="rgb(254, 65, 53)" data-abgc="#333333" data-hovercolors>SHOP NOW!</a></div>
                -->
              </div>
              
              
              
            </li>
            <?php }?>
            
            <!--li data-thumb="//cdn.shopify.com/s/files/1/1408/4802/files/index01-slide-2_x1024.jpg?v=1495896759" data-transition="fade" data-slotamount="1" data-masterspeed="1000" data-saveperformance="off"  data-title="Slide">
              
              
              
              <img src="< ?=base_url();?>fassets/files/1/1408/4802/files/index01-slide-2_x1024d3f1.jpg?v=1495896759" alt="" data-bgposition="center center" data-bgfit="cover" data-bgrepeat="no-repeat" >
              
              
              
              
              
              
              <div class="tp-caption tp-resizeme lfr stb text-right"
                   data-x="right"
                   data-y="center"
                   data-hoffset="-405"
                   data-voffset="-20"
                   data-speed="600"
                   data-start="900"
                   data-easing="Power4.easeOut"
                   data-endeasing="Power4.easeIn"
                   data-responsive_offset="on"
                   style="z-index: 2;">
                <div class="tp-caption1-wd-1" style="color:rgb(254, 65, 53)">We'll Help to Manage</div>
                <div class="tp-caption1-wd-2" style="color:#333333">Your Online<br>Business</div>
                
                <div class="tp-caption1-wd-3"><a href="#" class="btn btn-lg" style="color:#ffffff; background:#fe4135;" data-c="#ffffff" data-ac="#ffffff" data-bgc="#fe4135" data-abgc="#333333" data-hovercolors>SHOP NOW!</a></div>
                
              </div>
              
              
              
            </li-->
            
            
             
            
          </ul>
        </div>
      </div>
    </div>
    
  </div>
</div>


</div>


</div>
<div id="shopify-section-1495646706337" class="shopify-section index-section"><div class="container " data-sectionname="index_productsfeatured">
  <h1 class="block-title">LATEST PRODUCTS</h1>
  
  	<div class="row product-listing products-mobile-arrow carousel-products-mobile">
		
<!--pRODUCT loop sTART==================================================================-->
	 <?php 
            if(!empty($latest_product))
                {
                    foreach ($latest_product as $latest)
                    { 
                        $id = $latest->id;
                        $name = $latest->product_name;
                        $description = $latest->product_description;
                        $price = $latest->product_price;
                        $image = $latest->product_image;
                        ?>	
	
		<div class="col-xs-6 col-sm-4 col-md-3">
		    <div class="product">
			    <div class="product_inside">
				    <div class="image-box">
					    <a href="<?=base_url();?>ProductDetail/<?=$latest->id;?>">
					         <?php
                                         $this->db->limit(1);
                                         $all_images = $this->db->get_where('tbl_meta',array('ref_id'=> $latest->id))->result_array(); 
                                            for($i=0; $i < count($all_images); $i++)
                                            {
                                            ?>
					        <img src="<?=base_url().$all_images[$i]['link'];?>" alt="<?=$latest->product_name;?>"/>
					        <?php } ?>
					    </a>
				    </div>
			    <h2 class="title"><a href="<?=base_url();?>ProductDetail/<?=$latest->id;?>"><?=$latest->product_name;?></a></h2>
					<div class="price"><span><span class=money>Rs. <?=$latest->product_price;?></span></span><span class="old-price hide"></span></div>
			    	<div class="description"><?=$latest->product_description;?></div>
			    	<span class="money">PV:  <?=$latest->pv;?> | BV:  <?=$latest->bv;?></span>
			    	<div class="product_inside_hover">
				    <div class="product_inside_info">
				    </div>
			    		 
			    		<?php  echo "<form action='".base_url()."cart/add' method='post' name='productformcart' id='addcartform'>
                                                                                    <input type='hidden' name='id'  value=".$latest->id.">
                                                                                    <input type='hidden' name='name'  value=".$latest->product_name.">
                                                                                    <input type='hidden' name='price' value=".$latest->product_price.">
                                                                                    <input type='hidden' name='image' value=".$latest->product_image.">
                                                                                     <input min='1' type='number' id='quantity' name='qty' value='1' class='form-control input-small' style='width:60px;display:none;'>
                                                                                     
                                                                                    <button type='submit'  class='btn btn-product_addtocart' name='action'><span class='icon icon-shopping_basket'></span> ADD TO CART</button>
                                                                                </form>"; ?>
			      	</div>
			    	</div>
		    </div>
		</div>
		<?php } 
	}  ?>
<!--pRODUCT loop eND==================================================================-->
    </div>
  
</div>

</div><div id="shopify-section-1495646719779" class="shopify-section  index-section"><div class="container hidden-mobile">
  <hr>
</div>


</div><div id="shopify-section-1495646726494" class="shopify-section index-section"><div class="container" data-sectionname="index_brands">
  <div class="row">
    
    <div class="carousel-brands" data-slick='{"slidesToShow": 5, "slidesToScroll": 2, "autoplay": false, "autoplaySpeed": 7000}'>
      
<div >
        <a href="#">
          
          <img src="<?=base_url();?>fassets/files/1/1408/4802/files/brand-01_large6c34.png?v=1495893348" alt="">
        </a>
      </div>
      
<div >
        <a href="#">
          
          <img src="<?=base_url();?>fassets/files/1/1408/4802/files/brand-02_large686a.png?v=1495893359" alt="">
        </a>
      </div>
      
<div >
        <a href="#">
          
          <img src="<?=base_url();?>fassets/files/1/1408/4802/files/brand-03_largebe2d.png?v=1495893364" alt="">
        </a>
      </div>
      
<div >
        <a href="#">
          
          <img src="<?=base_url();?>fassets/files/1/1408/4802/files/brand-04_large1910.png?v=1495893369" alt="">
        </a>
      </div>
      
<div >
        <a href="#">
          
          <img src="<?=base_url();?>fassets/files/1/1408/4802/files/brand-05_large0a06.png?v=1495893375" alt="">
        </a>
      </div>
      
<div >
        <a href="#">
          
          <img src="<?=base_url();?>fassets/files/1/1408/4802/files/brand-06_largefc04.png?v=1495893382" alt="">
        </a>
      </div>
      
<div >
        <a href="#">
          
          <img src="<?=base_url();?>fassets/files/1/1408/4802/files/brand-07_large808f.png?v=1495893387" alt="">
        </a>
      </div>
      
<div >
        <a href="#">
          
          <img src="<?=base_url();?>fassets/files/1/1408/4802/files/brand-08_largeb503.png?v=1495893392" alt="">
        </a>
      </div>
      
<div >
        <a href="#">
          
          <img src="<?=base_url();?>fassets/files/1/1408/4802/files/brand-09_large3547.png?v=1495893397" alt="">
        </a>
      </div>
      
    </div>
    
  </div>
</div>

</div><div id="shopify-section-1495646741460" class="shopify-section index-section">



<div class="container-fluid">
  <div class="row">
    <a href="#" class="home4_banner_big zoom-in" data-hovercolors>
      <img src="<?=base_url();?>fassets/files/1/1408/4802/files/index01_b01_2048xbf12.jpg?v=1495894429" alt="">
      
      <div class="description text-center">
        <div class="container">
          <div class="block-table">
            <div class="block-table-cell">
              <p style="color:#333333">Grow your business with</p>
              <div class="title" style="color:#333333"></div>
              </div>
          </div>
        </div>
      </div>
    </a>
  </div>
</div>

</div> 

</div> 


</div><!-- END content_for_index -->

</div><div id="shopify-section-footer" class="shopify-section">


<link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">





<?php  require_once 'footer_pro.php';?>




</div><div class="modal fade" id="ModalquickView" tabindex="-1" role="dialog" aria-label="myModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content ">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true"><span class="icon icon-clear"></span></button>
      </div>
      <form>
        <div class="modal-body">
          <!--modal-quick-view-->
          <div class="modal-quick-view">
            <div class="row">
              <div class="col-sm-5 col-lg-6">
                <div class="product-main-image">
                  <!--<img src='images/product/product-big-1.jpg' alt="" />-->
                </div>
              </div>
              <div class="col-sm-7 col-lg-6">
                <div class="product-info">
                  <div class="add-info">
                    <div class="sku pull-left">
                      <span class="font-weight-medium color-defaulttext2">SKU:</span> <span>mtk012c</span>
                    </div>
                    <div class="availability pull-left">
                      <span class="font-weight-medium color-defaulttext2">Availability:</span> <span class="color-base stock_quantity hide"></span> <span class="color-base in_stock hide">in stock</span> <span class="color-base many_in_stock hide">Many in stock</span> <span class="color-red sold_out hide">Out of stock</span>
                    </div>
                  </div>
                  <h1 class="title"></h1>
                  <div class="price"><span></span><span class="old-price hide"></span></div>
                  
                  
                  <div class="add-info">
                    <ul class="productvendorsmallinfo">
                      <li><span>Vendor:</span> <span class="qv_vendor"></span></li>
                      <li><span>Product Type:</span> <span class="qv_type"></span></li>
                      <li><span>Barcode:</span> <span class="barcode"></span></li>
                    </ul>
                  </div>
                  
                  
                  
                  
                    <div class="description hidden-xs">
                      <!--<div class="text"></div>-->
                    </div>
                  

                  <div class="quickview-swatches-container" data-swatches-design="false"></div>
                  
                  <div class="wrapper">
                    <div class="pull-left"><label class="qty-label">QTY:</label></div>
                    <div class="pull-left">
                      <div class="style-2 input-counter">
                        <span class="minus-btn"></span>
                        <input type="text" value="1" size="5"/>
                        <span class="plus-btn"></span>
                      </div>
                    </div>
                    <div class="pull-left">
                      <a href="#" class="btn btn-addtocart addtocart-js"></a>
                    </div>
                  </div>

                  <div class="wrapper">
                    <a href="#" class="viewfullinfo">View Full Info</a>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <!--/modal-quick-view-->
        </div>
      </form>
    </div>
  </div>
</div>






<script>
var $ = jQuery.noConflict();
$(function() {
  // Current Ajax request.
  var currentAjaxRequest = null;
  // Grabbing all search forms on the page, and adding a .search-results list to each.
  var searchForms = $('form[action="/search"]').css('position','relative').each(function() {
    // Grabbing text input.
    var input = $(this).find('input[name="q"]');
    // Adding a list for showing search results.
    var offSet = input.position().top + input.innerHeight() + 1;
    $('<ul class="search-results"></ul>').css( { 'position': 'absolute', 'left': '0px', 'top': offSet } ).appendTo($(this)).hide();    
    // Listening to keyup and change on the text field within these search forms.
    input.attr('autocomplete', 'off').bind('keyup change', function() {
      // What's the search term?
      var term = $(this).val();
      // What's the search form?
      var form = $(this).closest('form');
      // What's the search URL?
      var searchURL = '/search?type=product&q=' + term;
      // What's the search results list?
      var resultsList = form.find('.search-results');
      // If that's a new term and it contains at least 3 characters.
      if (term.length > 3 && term != $(this).attr('data-old-term')) {
        // Saving old query.
        $(this).attr('data-old-term', term);
        // Killing any Ajax request that's currently being processed.
        if (currentAjaxRequest != null) currentAjaxRequest.abort();
        // Pulling results.
        currentAjaxRequest = $.getJSON(searchURL + '&view=json', function(data) {
          // Reset results.
          resultsList.empty();
          // If we have no results.
          if(data.results_count == 0) {
            // resultsList.html('<li><span class="title">No results.</span></li>');
            // resultsList.fadeIn(200);
            resultsList.hide();
          } else {
            // If we have results.
            $.each(data.results, function(index, item) {
              var link = $('<a></a>').attr('href', item.url);
              link.append('<span class="thumbnail"><img src="' + item.thumbnail + '" /></span>');
              link.append('<span class="title">' + item.title + '</span>');
              link.wrap('<li></li>');
              resultsList.append(link.parent());
            });
            // The Ajax request will return at the most 10 results.
            // If there are more than 10, let's link to the search results page.
            if(data.results_count > 10) {
              resultsList.append('<li><span class="title"><a href="' + searchURL + '">See all results (' + data.results_count + ')</a></span></li>');
            }
            resultsList.fadeIn(200);
          }
          $('.search-results').css( { 'width': input.innerWidth() + 2 });
        });
      }
    });
    //setTimeout(function(){ )}, 5);
  });
  // Clicking outside makes the results disappear.
  $('body').bind('click', function(){
    $('.search-results').hide();
  });
  $(window).resize(function(){
    var input = $('form[action="/search"]').find('input[name="q"]');
    if(input.length == 0) return false;
    var offSet = input.position().top + input.innerHeight() + 1;
    
    $('.search-results').css( { 'position': 'absolute', 'left': '0px', 'top': offSet, 'width': input.innerWidth() + 2 } );
  })
});
</script>
<div id="custom-preloader">
  <div class="custom-loader" style="display: none;">
    <img width="32" height="32" alt="" src="<?=base_url();?>fassets/ajax-loader760d.gif">
  </div>
</div>
<nav class="panel-menu mainmenu-mobile">
  <ul>
    
    <li>
      <a href="">HOME</a>

      
      
       <ul>
        
        	<li>
          		<a href="#">Home Page 1</a>
        	</li>
        
     
        </ul>
      

    </li>
    
    
    <li>
      <a href="#">ABOUT</a>
	</li>
    
    
  </ul>
</nav>
<!-- modalAddToCart -->
<div class="modal  fade"  id="modalAddToCartError" tabindex="-1" role="dialog" aria-label="myModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-sm">
    <div class="modal-content ">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true"><span class="icon icon-clear"></span></button>
      </div>
      <div class="modal-body">
        <div class="modal-add-cart">
          <span class="icon icon-remove_circle"></span>
          <p class="error_message"></p>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- modalAddToCartProduct -->
<div class="modal  fade"  id="modalAddToCartProduct" tabindex="-1" role="dialog" aria-label="myModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-md">
    <div class="modal-content ">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true"><span class="icon icon-clear"></span></button>
      </div>
      <div class="modal-body">
        <div class="modal-add-cart-product desctope">
          <div class="row">
            <div class="col-sm-6">
              <div class="modal-messages">
                <span class="icon color-base icon-check_circle"></span>
                <p>
                  Product successfully added to your shopping cart
                </p>
              </div>
              <div class="modal-product">
                <div class="image-box"></div>
                <div class="title"></div>
                <div class="description"></div>
                <div class="qty">Qty: <span></span></div>
              </div>
              <div class="total total-product-js">TOTAL: <span></span></div>
            </div>
            <div class="col-sm-6">
              <a href="cart.html" title="View Cart">
                <div class="cart-item-total">
                  <div class="cart-item-icon">
                    <span class="icon icon-shopping_basket"></span>View Cart
                  </div>
                  <p>
                    There are <span class="modal-total-quantity"></span> items<br> in your cart
                  </p>
                </div>
                <div class="total">
                  TOTAL: <span class="full-total-js"></span>
                </div>
              </a>
              <a href="#" class="btn invert close-modal-added-js">CONTINUE SHOPPING</a>
              <a href="checkout.html" class="btn">PROCEED TO CHECKOUT</a>
            </div>
          </div>
        </div>
        <div class="modal-add-cart-product mobile">
          <div class="modal-messages">
            <span class="icon color-base icon-check_circle"></span>
            <p>Added to cart successfully!</p>
          </div>
          <a href="#" class="btn btn-underline close-modal-added-js">CONTINUE SHOPPING</a>
          <a href="cart.html" class="btn btn-underline text-uppercase">View Cart</a>
          <a href="checkout.html" class="btn btn-underline">PROCEED TO CHECKOUT</a>
        </div>
      </div>
    </div>
  </div>
</div>

<!--JS============================================================================================
	<script src="<?=base_url();?>fassets/bootstrap.min760d.js" type="text/javascript"></script>
	<script src="<?=base_url();?>fassets/slick.min760d.js" type="text/javascript"></script>
	<script src="<?=base_url();?>fassets/assets/themes_support/api.jquery-0ea851da22ae87c0290f4eeb24bc8b513ca182f3eb721d147c009ae0f5ce14f9.js" type="text/javascript"></script>
	<script src="<?=base_url();?>fassets/cart.api760d.js" type="text/javascript"></script>
	<div class="revolution_included"></div>
	<script src="<?=base_url();?>fassets/jquery.themepunch.tools.min760d.js" type="text/javascript"></script>
	<script src="<?=base_url();?>fassets/jquery.themepunch.revolution.min760d.js" type="text/javascript"></script>
	<script src="<?=base_url();?>fassets/moment-momenttimezone.min760d.js" type="text/javascript"></script>
	<script src="<?=base_url();?>fassets/jquery.plugin.min760d.js" type="text/javascript"></script>
    <script src="<?=base_url();?>fassets/jquery.countdown.min760d.js" type="text/javascript"></script>
	<script src="<?=base_url();?>fassets/instafeed.min760d.js" type="text/javascript"></script>
	<script src="<?=base_url();?>fassets/swatches760d.js" type="text/javascript"></script>
	
	<script src="<?=base_url();?>fassets/panelmenu760d.js" type="text/javascript"></script>
	<script src="<?=base_url();?>fassets/main760d.js" type="text/javascript"></script>
	<script src="<?=base_url();?>fassets/javascripts/currencies.js" type="text/javascript"></script>
	<script src="<?=base_url();?>fassets/jquery.currencies.min760d.js" type="text/javascript"></script>
	<script src="../apis.google.com/js/platform.js"></script-->
</body>
</html>
