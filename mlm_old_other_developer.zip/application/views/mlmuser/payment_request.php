<?php 
 include 'inc/head.php';
?>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

 <?php include 'inc/header.php';
 ?>
  <!-- Left side column. contains the logo and sidebar -->
 <?php include 'inc/sidebar.php';
 ?>
<style>
    .olxc > div
    {
        display:none!important;
    }
    .olxc 
    {
        min-height:inherit!important;
    }
</style>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper olxc">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Dashboard
        
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Dashboard</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <!-- Info boxes -->
      <div class="row">
        <div class="col-md-3 col-sm-6 col-xs-12">
          <div class="info-box">
            <span class="info-box-icon bg-aqua"><i class="ion ion-cash"></i></span>
<?php $earningsC = 0 ; $earningsP = 0 ; $earningso = 0; for($e=0;$e< count($earnings);$e++) 
                    { //total earnings
                        $earningsC = $earningsC + $earnings[$e]['wallet'] ; 
                      //balance
                        if($earnings[$e]['withdrawls'] == 0)
                        {
                            $earningsP = $earningsP + $earnings[$e]['wallet']  ; 
                        }
                        if($earnings[$e]['withdrawls'] == 1)
                        {
                            $earningso = $earningso + $earnings[$e]['wallet']  ; 
                        }
                    
                    } 
                    if($earningsP != 0)
                    {
                        $percentageAm = ($earningsP / $earningsC)*100;
                    }    
                    
                    ?>
            <div class="info-box-content">
              <span class="info-box-text">Wallet</span>
              <span class="info-box-number"><?=$earningsP;?> <small>PKR</small></span>
            </div>
            <!-- /.info-box-content -->
          </div>
          <!-- /.info-box -->
        </div>
        <!-- /.col -->
        <div class="col-md-3 col-sm-6 col-xs-12">
          <div class="info-box">
            <span class="info-box-icon bg-red"><i class="ion ion-cash"></i></span>

            <div class="info-box-content">
              <span class="info-box-text">Total Payouts</span>
              <span class="info-box-number"><?=$earningso;?> <small>PKR</small></span>
            </div>
            <!-- /.info-box-content -->
          </div>
          <!-- /.info-box -->
        </div>
        <!-- /.col -->

        <!-- fix for small devices only -->
        <div class="clearfix visible-sm-block"></div>

        <div class="col-md-3 col-sm-6 col-xs-12">
          <div class="info-box">
            <span class="info-box-icon bg-green"><i class="ion ion-ios-personadd-outline"></i></span>

            <div class="info-box-content">
              <span class="info-box-text">Comission</span>
              <span class="info-box-number"><?php echo $earningsC; ?> <small>PKR</small></span>
            </div>
            <!-- /.info-box-content -->
          </div>
          <!-- /.info-box -->
        </div>
        <!-- /.col -->
        <div class="col-md-3 col-sm-6 col-xs-12">
          <div class="info-box">
            <span class="info-box-icon bg-yellow"><i class="ion ion-android-cart"></i></span>
<?php $purchaseX = 0; for( $p=0; $p< count($purchases); $p++ ){ $purchaseX = $purchaseX + $purchases[$p]['grand_amount']; } ?>
            <div class="info-box-content">
              <span class="info-box-text">My Purchases</span>
              <span class="info-box-number"><?=$purchaseX;?> <small>PKR</small></span>
            </div>
            <!-- /.info-box-content -->
          </div>
          <!-- /.info-box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
 <div class="row">
        <div class="col-md-12">
          <div class="box">
            <div class="box-header">
              <h3 class="box-title">Request Payout</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
                <?php if(isset($_GET['success']) )
                {
                echo "<b>Payout Requested Successfully.</b>";
                }
                if(isset($earningsP) && $earningsP > 2000)
                {
                ?>
            <a class="btn btn-primary" href="<?=base_url();?>payOut">Request Payout - <?=$earningsP;?>/- PKR</a>
            <?php } ?>
            </div>
            <!-- /.box-body -->
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      </div>
      <!-- /.row -->
      <div class="row">
        <div class="col-md-12">
          <div class="box">
            <div class="box-header">
              <h3 class="box-title">Payment History</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th>Ammount</th>
                  <th>Status</th>
                  <th>Date (Requested)</th>
                  <th>Date (Payout)</th>
                  
                </tr>
                </thead>
                <tbody>
                    <?php 
                    for($o=0;$o<count($pay_history);$o++)
                    {
                    ?>
                <tr>
                  <td><?=$pay_history[$o]['ammount'];?></td>
                  <td><?php if($pay_history[$o]['status'] == 1){ echo "In Process";}else if($pay_history[$o]['status'] == 0){ echo "Paid"; } ?></td>
                  <td><?=$pay_history[$o]['date_reruest'];?></td>
                  <td><?=$pay_history[$o]['date_paid'];?></td>
                </tr>
                <?php } ?>
                </tbody>
                <tfoot>
                <tr>
                  <th>Ammount</th>
                  <th>Status</th>
                  <th>Date (Requested)</th>
                  <th>Date (Payout)</th>
                </tr>
                </tfoot>
              </table>
            </div>
            <!-- /.box-body -->
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->

      <!-- Main row -->
      
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

  <?php include 'inc/footer.php';
  ?>