<?php 
 include 'inc/head.php';
?>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

 <?php include 'inc/header.php';
 ?>
  <!-- Left side column. contains the logo and sidebar -->
 <?php include 'inc/sidebar.php';
 ?>
<style>
    .olxc > div
    {
        display:none!important;
    }
    .olxc 
    {
        min-height:inherit!important;
    }
</style>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper olxc">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Dashboard
        
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Dashboard</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <!-- Info boxes -->
      <div class="row">
        <div class="col-md-3 col-sm-6 col-xs-12">
          <div class="info-box">
            <span class="info-box-icon bg-aqua"><i class="ion ion-cash"></i></span>
<?php $earningsC = 0 ; $earningsP = 0 ; $earningso = 0; for($e=0;$e< count($earnings);$e++) 
                    { //total earnings
                        $earningsC = $earningsC + $earnings[$e]['wallet'] ; 
                      //balance
                        if($earnings[$e]['withdrawls'] == 0)
                        {
                            $earningsP = $earningsP + $earnings[$e]['wallet']  ; 
                        }
                        if($earnings[$e]['withdrawls'] == 1)
                        {
                            $earningso = $earningso + $earnings[$e]['wallet']  ; 
                        }
                    
                    } 
                    if($earningsP != 0)
                    {
                        $percentageAm = ($earningsP / $earningsC)*100;
                    }                
                    ?>
            <div class="info-box-content">
              <span class="info-box-text">Wallet</span>
              <span class="info-box-number"><?=$earningsP;?> <small>PKR</small></span>
            </div>
            <!-- /.info-box-content -->
          </div>
          <!-- /.info-box -->
        </div>
        <!-- /.col -->
        <div class="col-md-3 col-sm-6 col-xs-12">
          <div class="info-box">
            <span class="info-box-icon bg-red"><i class="ion ion-cash"></i></span>

            <div class="info-box-content">
              <span class="info-box-text">Total Payouts</span>
              <span class="info-box-number"><?=$earningso;?> <small>PKR</small></span>
            </div>
            <!-- /.info-box-content -->
          </div>
          <!-- /.info-box -->
        </div>
        <!-- /.col -->

        <!-- fix for small devices only -->
        <div class="clearfix visible-sm-block"></div>

        <div class="col-md-3 col-sm-6 col-xs-12">
          <div class="info-box">
            <span class="info-box-icon bg-green"><i class="ion ion-ios-personadd-outline"></i></span>

            <div class="info-box-content">
              <span class="info-box-text">Comission</span>
              <span class="info-box-number"><?php echo $earningsC; ?> <small>PKR</small></span>
            </div>
            <!-- /.info-box-content -->
          </div>
          <!-- /.info-box -->
        </div>
        <!-- /.col -->
        <div class="col-md-3 col-sm-6 col-xs-12">
          <div class="info-box">
            <span class="info-box-icon bg-yellow"><i class="ion ion-android-cart"></i></span>
<?php $purchaseX = 0; for( $p=0; $p< count($purchases); $p++ ){ $purchaseX = $purchaseX + $purchases[$p]['grand_amount']; } ?>
            <div class="info-box-content">
              <span class="info-box-text">My Purchases</span>
              <span class="info-box-number"><?=$purchaseX;?> <small>PKR</small></span>
            </div>
            <!-- /.info-box-content -->
          </div>
          <!-- /.info-box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->

      <div class="row">
        <div class="col-md-12 mytree">
          <div class="box">
            <div class="box-header with-border">
              <h3 class="box-title">My Tree</h3>

              <div class="box-tools pull-right">
                
                <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
              </div>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <div class="row">
                 
                <!-- /.col -->
                <div class="col-md-12">
                  <!--tree code-->
                    
<div class="tree">
  <ul>
    <li>
        <?php
        $offsetID = $this->uri->segment(2);
        $rangeID  = $this->uri->segment(3);
        $ParentData = $this->db->get_where('tbl_customers',array('customer_id'=>$offsetID))->result_array();
        ?>
        <?php 
        $this->db->limit(14);
        $C1Data = $this->db->get_where('tbl_refferal',array('refferral_id'=>$_SESSION['userid'],'id >'=> $rangeID))->result_array();
           if(!empty($C1Data))
           {
               for($m=0; $m < count($C1Data); $m++)
               {
                   //$C1personalData[$m] = $this->db->get_where('tbl_customers',array('customer_id'=>$C1Data[$m]['customer_id']))->result_array();
               }
           }
           
           //$C1personalData = $this->db->get_where('tbl_customers',array('customer_id'=>$C1Data[]['userid']))->result_array();
           ?>
            
      <a href="#"><?=$ParentData[0]['first_name']."(".$ParentData[0]['first_name'].")";?></a>
      <ul>
          <?php if(!empty($C1Data))
          {
          ?>
        <li>
          
                   <?php 
                    if(!empty($C1Data[0]['customer_id']))
                  {
                      ?>
                       <a href="<?=base_url().'my-tree-extended/'.$C1Data[0]['customer_id'].'/'.$C1Data[0]['id'];?>">
                      <?php
              $C1personalData = $this->db->get_where('tbl_customers',array('customer_id'=>$C1Data[0]['customer_id']))->result_array(); ?>
           <?php if(!empty($C1personalData)) { echo $C1personalData[0]['first_name'];  } ?></a> <?php } ?>
          <ul>
            <li>
                <?php
                if(!empty($C1Data[2]['customer_id']))
                  {
                
                ?>
              <a href="<?=base_url().'my-tree-extended/'.$C1Data[2]['customer_id'].'/'.$C1Data[2]['id'];?>">
                   <?php 
                    
              $C1personalData = $this->db->get_where('tbl_customers',array('customer_id'=>$C1Data[2]['customer_id']))->result_array(); ?>
           <?php if(!empty($C1personalData)) { echo $C1personalData[0]['first_name']; }  ?></a><?php } ?>
              <ul>
                <li>
                    <?php
                    if(!empty($C1Data[6]['customer_id']))
                    {
                    ?>
                  <a href="<?=base_url().'my-tree-extended/'.$C1Data[6]['customer_id'].'/'.$C1Data[6]['id'];?>">
                   <?php 
                    
              $C1personalData = $this->db->get_where('tbl_customers',array('customer_id'=>$C1Data[6]['customer_id']))->result_array(); ?>
           <?php if(!empty($C1personalData)) { echo $C1personalData[0]['first_name']; } ?></a><?php } ?>
                </li>
                <li>
                    <?php
                    if(!empty($C1Data[7]['customer_id']))
                    {
                    ?>
                  <a href="<?=base_url().'my-tree-extended/'.$C1Data[7]['customer_id'].'/'.$C1Data[7]['id'];?>">
                   <?php 
                    
              $C1personalData = $this->db->get_where('tbl_customers',array('customer_id'=>$C1Data[7]['customer_id']))->result_array(); ?>
           <?php if(!empty($C1personalData)) { echo $C1personalData[0]['first_name']; }  ?></a><?php } ?>
                </li>
              </ul>
            </li>
            <li>
                <?php 
                if(!empty($C1Data[3]['customer_id']))
                  {
                ?>
               <a href="<?=base_url().'my-tree-extended/'.$C1Data[3]['customer_id'].'/'.$C1Data[3]['id'];?>">
                   <?php 
                    
              $C1personalData = $this->db->get_where('tbl_customers',array('customer_id'=>$C1Data[3]['customer_id']))->result_array(); ?>
           <?php if(!empty($C1personalData)) { echo $C1personalData[0]['first_name']; }  ?></a><?php } ?>
              <ul>
                <li>
                    <?php 
                     if(!empty($C1Data[8]['customer_id']))
                        {
                    ?>
                    <a href="<?=base_url().'my-tree-extended/'.$C1Data[8]['customer_id'].'/'.$C1Data[8]['id'];?>">
                   <?php 
                   
              $C1personalData = $this->db->get_where('tbl_customers',array('customer_id'=>$C1Data[8]['customer_id']))->result_array(); ?>
           <?php if(!empty($C1personalData)) { echo $C1personalData[0]['first_name']; }  ?></a><?php } ?>
                </li>
                <li>
                    <?php 
                    if(!empty($C1Data[9]['customer_id']))
                    {
                    ?>
                  <a href="<?=base_url().'my-tree-extended/'.$C1Data[9]['customer_id'].'/'.$C1Data[9]['id'];?>"> <?php 
                   
              $C1personalData = $this->db->get_where('tbl_customers',array('customer_id'=>$C1Data[9]['customer_id']))->result_array(); ?>
           <?php if(!empty($C1personalData)) { echo $C1personalData[0]['first_name']; }  ?></a> <?php } ?>
                </li>
              </ul>
            </li>
          </ul>
        </li>
        <?php } ?>
        <li>
            <?php
                if(!empty($C1Data[1]['customer_id']))
                  {
            ?>
          <a href="<?=base_url().'my-tree-extended/'.$C1Data[1]['customer_id'].'/'.$C1Data[1]['id'];?>">
                   <?php 
                
              $C1personalData = $this->db->get_where('tbl_customers',array('customer_id'=>$C1Data[1]['customer_id']))->result_array(); ?>
           <?php if(!empty($C1personalData)) { echo $C1personalData[0]['first_name']; }  ?></a> <?php } ?>
          <ul>
            
            <li>
                <?php 
                 if(!empty($C1Data[4]['customer_id']))
                  {
                ?>
                <a href="<?=base_url().'my-tree-extended/'.$C1Data[4]['customer_id'].'/'.$C1Data[4]['id'];?>">
                   <?php 
                   
              $C1personalData = $this->db->get_where('tbl_customers',array('customer_id'=>$C1Data[4]['customer_id']))->result_array(); ?>
           <?php if(!empty($C1personalData)) { echo $C1personalData[0]['first_name']; }  ?></a><?php } ?>
              <ul>
                <li>
                    <?php 
                    if(!empty($C1Data[10]['customer_id']))
                  {
                    ?>
                  <a href="<?=base_url().'my-tree-extended/'.$C1Data[10]['customer_id'].'/'.$C1Data[10]['id'];?>">
                   <?php 
                    
              $C1personalData = $this->db->get_where('tbl_customers',array('customer_id'=>$C1Data[10]['customer_id']))->result_array(); ?>
           <?php if(!empty($C1personalData)) { echo $C1personalData[0]['first_name']; }  ?></a><?php } ?>
                </li>
                <li>
                    <?php 
                    if(!empty($C1Data[11]['customer_id']))
                  {
                    ?>
                  <a href="<?=base_url().'my-tree-extended/'.$C1Data[11]['customer_id'].'/'.$C1Data[11]['id'];?>">
                   <?php 
                    
              $C1personalData = $this->db->get_where('tbl_customers',array('customer_id'=>$C1Data[11]['customer_id']))->result_array(); ?>
           <?php if(!empty($C1personalData)) { echo $C1personalData[0]['first_name']; }  ?></a><?php } ?>
                </li>
              </ul>
            </li>
            <li>
                <?php
                if(!empty($C1Data[5]['customer_id']))
                  {
                ?>
              <a href="<?=base_url().'my-tree-extended/'.$C1Data[5]['customer_id'].'/'.$C1Data[5]['id'];?>">
                   <?php 
                    
              $C1personalData = $this->db->get_where('tbl_customers',array('customer_id'=>$C1Data[5]['customer_id']))->result_array(); ?>
           <?php if(!empty($C1personalData)) { echo $C1personalData[0]['first_name']; }  ?></a><?php } ?>
              <ul>
                <li>
                    <?php
                     if(!empty($C1Data[12]['customer_id']))
                    {
                    ?>
                  <a href="<?=base_url().'my-tree-extended/'.$C1Data[12]['customer_id'].'/'.$C1Data[12]['id'];?>"> <?php 
                 
              $C1personalData = $this->db->get_where('tbl_customers',array('customer_id'=>$C1Data[12]['id']))->result_array(); ?>
          <?php if(!empty($C1personalData)) { echo $C1personalData[0]['first_name']; } ?></a><?php } ?>
                </li>
                <li>
                    <?php 
                     if(!empty($C1Data[13]['customer_id']))
                  {
                    ?>
                 <a href="<?=base_url().'my-tree-extended/'.$C1Data[13]['customer_id'].'/'.$C1Data[13]['id'];?>">
                   <?php 
                   
              $C1personalData = $this->db->get_where('tbl_customers',array('customer_id'=>$C1Data[7]['customer_id']))->result_array(); ?>
           <?php if(!empty($C1personalData)) { echo $C1personalData[0]['first_name']; }  ?></a> <?php } ?>
                </li>
              </ul>
            </li>
             
          </ul>
        </li>
      </ul>
    </li>
  </ul>
</div>
<style type="text/css">
  /*Now the CSS*/
* {margin: 0; padding: 0;}

.mytree .tree ul {
  padding-top: 20px; position: relative;
  
  transition: all 0.5s;
  -webkit-transition: all 0.5s;
  -moz-transition: all 0.5s;
}

.mytree .tree li {
  float: left; text-align: center;
  list-style-type: none;
  position: relative;
  padding: 20px 5px 0 5px;
  transition: all 0.5s;
  -webkit-transition: all 0.5s;
  -moz-transition: all 0.5s;
}

/*We will use ::before and ::after to draw the connectors*/

.mytree .tree li::before, .tree li::after{
  content: '';
  position: absolute; top: 0; right: 50%;
  border-top: 1px solid #ccc;
  width: 50%; height: 20px;
}
.mytree .tree li::after{
  right: auto; left: 50%;
  border-left: 1px solid #ccc;
}

/*We need to remove left-right connectors from elements without 
any siblings*/
.mytree .tree li:only-child::after, .tree li:only-child::before {
  display: none;
}

/*Remove space from the top of single children*/
.mytree .tree li:only-child{ padding-top: 0;}

/*Remove left connector from first child and 
right connector from last child*/
.mytree .tree li:first-child::before, .tree li:last-child::after{
  border: 0 none;
}
/*Adding back the vertical connector to the last nodes*/
.mytree .tree li:last-child::before{
  border-right: 1px solid #ccc;
  border-radius: 0 5px 0 0;
  -webkit-border-radius: 0 5px 0 0;
  -moz-border-radius: 0 5px 0 0;
}
.mytree .tree li:first-child::after{
  border-radius: 5px 0 0 0;
  -webkit-border-radius: 5px 0 0 0;
  -moz-border-radius: 5px 0 0 0;
}

/*Time to add downward connectors from parents*/
.mytree .tree ul ul::before{
  content: '';
  position: absolute; top: 0; left: 50%;
  border-left: 1px solid #ccc;
  width: 0; height: 20px;
}

.mytree .tree li a{
  border: 1px solid #ccc;
  padding: 5px 10px;
  text-decoration: none;
  color: #666;
  font-family: arial, verdana, tahoma;
  font-size: 11px;
  display: inline-block;
  
  border-radius: 5px;
  -webkit-border-radius: 5px;
  -moz-border-radius: 5px;
  
  transition: all 0.5s;
  -webkit-transition: all 0.5s;
  -moz-transition: all 0.5s;
}

/*Time for some hover effects*/
/*We will apply the hover effect the the lineage of the element also*/
.mytree .tree li a:hover, .tree li a:hover+ul li a {
  background: #c8e4f8; color: #000; border: 1px solid #94a0b4;
}
/*Connector styles on hover*/
.mytree .tree li a:hover+ul li::after, 
.mytree .tree li a:hover+ul li::before, 
.mytree .tree li a:hover+ul::before, 
.mytree .tree li a:hover+ul ul::before{
  border-color:  #94a0b4;
}

/*Thats all. I hope you enjoyed it.
Thanks :)*/
</style>
                  <!--tree code-->
                </div>
                <!-- /.col -->
              </div>
              <!-- /.row -->
            </div>
            <!-- ./box-body -->
            <div class="box-footer">
          
              <!-- /.row -->
            </div>
            <!-- /.box-footer -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->

      <!-- Main row -->
      
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

  <?php include 'inc/footer.php';
  ?>