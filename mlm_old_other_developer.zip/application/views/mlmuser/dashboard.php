<?php 
 include 'inc/head.php';
?>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

 <?php include 'inc/header.php';
 ?>
  <!-- Left side column. contains the logo and sidebar -->
 <?php include 'inc/sidebar.php';
 ?>
<style>
    .olxc > div
    {
        display:none!important;
    }
    .olxc 
    {
        min-height:inherit!important;
    }
</style>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper olxc">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Dashboard
        
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Dashboard</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <!-- Info boxes -->
      <div class="row">
        <div class="col-md-3 col-sm-6 col-xs-12">
          <div class="info-box">
            <span class="info-box-icon bg-aqua"><i class="ion ion-cash"></i></span>
<?php $earningsC = 0 ; $earningsP = 0 ; $earningso = 0; for($e=0;$e< count($earnings);$e++) 
                    { //total earnings
                        $earningsC = $earningsC + $earnings[$e]['wallet'] ; 
                      //balance
                        if($earnings[$e]['withdrawls'] == 0)
                        {
                            $earningsP = $earningsP + $earnings[$e]['wallet']  ; 
                        }
                        if($earnings[$e]['withdrawls'] == 1)
                        {
                            $earningso = $earningso + $earnings[$e]['wallet']  ; 
                        }
                    
                    } 
                    if($earningsP != 0)
                    {
                        $percentageAm = ($earningsP / $earningsC)*100;
                    }    
                    
                    ?>
            <div class="info-box-content">
              <span class="info-box-text">Wallet</span>
              <span class="info-box-number"><?=$earningsP;?> <small>PKR</small></span>
            </div>
            <!-- /.info-box-content -->
          </div>
          <!-- /.info-box -->
        </div>
        <!-- /.col -->
        <div class="col-md-3 col-sm-6 col-xs-12">
          <div class="info-box">
            <span class="info-box-icon bg-red"><i class="ion ion-cash"></i></span>

            <div class="info-box-content">
              <span class="info-box-text">Total Payouts</span>
              <span class="info-box-number"><?=$earningso;?> <small>PKR</small></span>
            </div>
            <!-- /.info-box-content -->
          </div>
          <!-- /.info-box -->
        </div>
        <!-- /.col -->

        <!-- fix for small devices only -->
        <div class="clearfix visible-sm-block"></div>

        <div class="col-md-3 col-sm-6 col-xs-12">
          <div class="info-box">
            <span class="info-box-icon bg-green"><i class="ion ion-ios-personadd-outline"></i></span>

            <div class="info-box-content">
              <span class="info-box-text">Comission</span>
              <span class="info-box-number"><?php echo $earningsC; ?> <small>PKR</small></span>
            </div>
            <!-- /.info-box-content -->
          </div>
          <!-- /.info-box -->
        </div>
        <!-- /.col -->
        <div class="col-md-3 col-sm-6 col-xs-12">
          <div class="info-box">
            <span class="info-box-icon bg-yellow"><i class="ion ion-android-cart"></i></span>
<?php $purchaseX = 0; for( $p=0; $p< count($purchases); $p++ ){ $purchaseX = $purchaseX + $purchases[$p]['grand_amount']; } ?>
            <div class="info-box-content">
              <span class="info-box-text">My Purchases</span>
              <span class="info-box-number"><?=$purchaseX;?> <small>PKR</small></span>
            </div>
            <!-- /.info-box-content -->
          </div>
          <!-- /.info-box -->
        </div>
        <div class="col-md-12 col-sm-6 col-xs-12">
          <div class="info-box">
            <span class="info-box-icon bg-yellow"><i class="ion ion-ios-personadd-outline"></i></span>

            <div class="info-box-content">
              <span class="info-box-text">My ID</span>
              <span class="info-box-number"><?=$_SESSION['userid'];?></span>
            </div>
            <!-- /.info-box-content -->
          </div>
          <!-- /.info-box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->

      <div class="row">
        <div class="col-md-12">
          <div class="box">
            <div class="box-header with-border">
              <h3 class="box-title">Recap Report</h3>

              <div class="box-tools pull-right">
                
                <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
              </div>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <div class="row">
                 
                <!-- /.col -->
                <div class="col-md-4">
                  <p class="text-center">
                    <strong>Goal Completion</strong>
                  </p>

                  <div class="progress-group">
                    <span class="progress-text">Members Reffered</span>
                    <span class="progress-number"><b><?php echo count($reffered); ?></b>/1024</span>
<?php
$numberPercentage = (count($reffered) / 1024) * 100 ; ?>
                    <div class="progress sm">
                      <div class="progress-bar progress-bar-aqua" style="width: <?=$numberPercentage;?>%"></div>
                    </div>
                  </div>
                  <!-- /.progress-group -->
                  <div class="progress-group">
                      <?php // =$earnings; ?>
                    <span class="progress-text">Member Lavel</span>
                    <span class="progress-number"><b><?php if(isset($meta[0]['level'])){ echo $meta[0]['level'];} else { echo 0;}?></b>/10</span>

                    <div class="progress sm">
                      <div class="progress-bar progress-bar-red" style="width: <?=$meta[0]['level']*10;?>%"></div>
                    </div>
                  </div>
                  <!-- /.progress-group -->
                  <div class="progress-group">
                    <span class="progress-text">Payouts VS Balance</span>
                    <?php $earningsC = 0 ; $earningsP = 0 ; for($e=0;$e< count($earnings);$e++) 
                    { //total earnings
                        $earningsC = $earningsC + $earnings[$e]['wallet'] ; 
                      //balance
                        if($earnings[$e]['withdrawls'] == 0)
                        {
                            $earningsP = $earningsP + $earnings[$e]['wallet']  ; 
                        }
                    
                    }
                    if(!empty($earningsP) || $earningsP!= 0)
                    {
                        $percentageAm = ($earningsP / $earningsC)*100;
                    }
                    else
                    {
                        $percentageAm = 0;
                    }
                    ?>
                    <span class="progress-number"><b><?php if(isset($earningsP)){ echo $earningsP; } ?></b>/<?=$earningsC;?></span>

                    <div class="progress sm">
                      <div class="progress-bar progress-bar-green" style="width: <?=$percentageAm;?>%"></div>
                    </div>
                  </div>
                  <!-- /.progress-group -->
               
                  <!-- /.progress-group -->
                </div>
                <!-- /.col -->
              </div>
              <!-- /.row -->
            </div>
            <!-- ./box-body -->
            <div class="box-footer">
          
              <!-- /.row -->
            </div>
            <!-- /.box-footer -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->

      <!-- Main row -->
      
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

  <?php include 'inc/footer.php';
  ?>