<footer data-nomargin>
  <div class="container-fluid">
  <div class="row">
    
  </div>
</div>
  <div class="footer-content-col no-padding-top" style="padding-bottom:0px!important;">
  






<div class="container">
  <div class="row" style="padding-bottom:25px;">
    
    
    
    
    
    
    <div class="col-sm-6 col-md-3">
      <div class="mobile-collapse">
        <h4 class="mobile-collapse_title visible-xs text-uppercase">Free Shipping</h4>
        <div class="mobile-collapse_content">
          <a href="#" class="services-block">
            <span class="icon icon-airplanemode_active"></span>
            <div class="title">Free Shipping</div>
            <p>Free on all products</p>
          </a>
        </div>
      </div>
    </div>
    
    
    
    
    
    
    
    
    <div class="col-sm-6 col-md-3">
      <div class="mobile-collapse">
        <h4 class="mobile-collapse_title visible-xs text-uppercase">Secured Shopping</h4>
        <div class="mobile-collapse_content">
          <a href="#" class="services-block">
            <span class="icon icon-security"></span>
            <div class="title">Secured Shopping</div>
            <p>We use the best security features</p>
          </a>
        </div>
      </div>
    </div>
    
    
    
    
    
    
    
    
    <div class="col-sm-6 col-md-3">
      <div class="mobile-collapse">
        <h4 class="mobile-collapse_title visible-xs text-uppercase">Free Returns</h4>
        <div class="mobile-collapse_content">
          <a href="#" class="services-block">
            <span class="icon icon-assignment_return"></span>
            <div class="title">Free Returns</div>
            <p>Return for free within 30 days</p>
          </a>
        </div>
      </div>
    </div>
    
    
    
    
    
    
    
    
    <div class="col-sm-6 col-md-3">
      <div class="mobile-collapse">
        <h4 class="mobile-collapse_title visible-xs text-uppercase">Support</h4>
        <div class="mobile-collapse_content">
          <a href="#" class="services-block">
            <span class="icon icon-headset_mic"></span>
            <div class="title">Support</div>
            <p>Effectiveand Friendly Support</p>
          </a>
        </div>
      </div>
    </div>
    
    
  </div>
</div>
<div class="container-fluid" style="background:#F5F5F7!important;">
  <div class="container" style="background:#F5F5F7!important;padding:52px;">
    <div class="row">
      
      
      
      
       

      
     <div class="col-md-3 col-sm-12 hidden-xs">
        <div class="row">
          <div class="col-sm-4 col-md-12">
            <div class="footer-logo">
              <a href="<?=base_url();?>">
                <img src="<?=base_url();?>images/logo.png" alt="">
                
              </a>
            </div>
          </div>
          <div class="col-sm-8 col-md-12">
            
            

<div class="social-icon-round">
  <ul>
    <li><a class="icon fa fa-facebook" href="#"></a></li>
    <li><a class="icon fa fa-twitter" href="#"></a></li>
    <li><a class="icon fa fa-google-plus" href="#"></a></li>
    <li><a class="icon fa fa-instagram" href="#"></a></li>
  </ul>
</div>


          </div>
        </div>
      </div>












<div class="col-sm-6 col-md-3">
  <div class="mobile-collapse">
    <h4 class="mobile-collapse_title text-uppercase">INFORMATION</h4>
    <div class="mobile-collapse_content">
      
      <div class="v-links-list">
        <ul>
          
          <li><a href="<?=base_url()?>faqs">About Us</a></li>
          
          <li><a href="<?=base_url()?>shipping">Privacy Policy</a></li>
          
          <li><a href="<?=base_url()?>term"> Terms & Conditions</a></li>
          
          <li><a href="<?=base_url()?>contact">Contact Us</a></li>
          
        </ul>
      </div>
      
      
    </div>
  </div>
</div>




<div class="col-sm-6 col-md-3">
  <div class="mobile-collapse">
    <h4 class="mobile-collapse_title text-uppercase">MY ACCOUNT</h4>
    <div class="mobile-collapse_content">
      
      <div class="v-links-list">
        <ul>
           <?php
                                    $sesUID = $this->session->userdata('userid');
                                    if(!empty($sesUID))
                                    {?>
                                   
                                        <li><a href="<?=base_url();?>login/logout" >Logout</a></li>
                                        <li><a href="<?=base_url();?>">My Account</a></li>
                                        <li><a href="<?=base_url()?>cart">View Cart</a></li>
                                    <?php }
                                    else {?>
                                        <li><a href="<?=base_url();?>login" >Login</a></li>
                                        <li><a href="<?=base_url();?>register" >Register</a></li>

                                        <li><a href="<?=base_url()?>cart">View Cart</a></li>

                                   <?php }
                                    
                                    ?>
          
          
          
          
          
         
          
        </ul>
      </div>
      
      
    </div>
  </div>
</div>









<div class="col-sm-6 col-md-3">
  <div class="mobile-collapse">
    <h4 class="mobile-collapse_title text-uppercase">CONTACTS</h4>
    <div class="mobile-collapse_content">
      
      <div class="list-info">
	<ul>
		<li>Address: 7563 St. Vicent Place, Glasgow</li>
		<li>Phone: +777 2345 7885</li>
		<li>Fax: +777 2345 7886</li>
		<li>Hours: 7 Days a week from 10:00 am</li>
		<li>E-mail: <a href="mailto:info@mydomain.com">info@mydomain.com</a>
</li>
	</ul>
</div>
    </div>
  </div>
</div>
</div>

    </div>
  </div>
</div>
  
  

<div class="copyright">

  
<div class="container visible-xs">
<div class="social-icon-round">
  <ul>
    <li><a class="icon fa fa-facebook" href="#"></a></li>
    <li><a class="icon fa fa-twitter" href="#"></a></li>
    <li><a class="icon fa fa-google-plus" href="#"></a></li>
    <li><a class="icon fa fa-instagram" href="#"></a></li>
  </ul>
</div>
</div>


  <div class="container">
    
      
      <div class="pull-right">
        <!--div class="payment-list">
  <ul><li><a href="#"><img src="<?=base_url();?>fassets/files/1/1408/4802/files/payment_icon_01_50x4dab.png?v=1496323455" alt=""></a></li><li><a href="#"><img src="<?=base_url();?>fassets/files/1/1408/4802/files/payment_icon_02_50xc9f8.png?v=1496323465" alt=""></a></li><li><a href="#"><img src="<?=base_url();?>fassets/files/1/1408/4802/files/payment_icon_03_50xfa71.png?v=1496323475" alt=""></a></li><li><a href="#"><img src="<?=base_url();?>fassets/files/1/1408/4802/files/payment_icon_04_50xf136.png?v=1496323481" alt=""></a></li><li><a href="#"><img src="<?=base_url();?>fassets/files/1/1408/4802/files/payment_icon_05_50x5d27.png?v=1496323489" alt=""></a></li><li><a href="#"><img src="<?=base_url();?>fassets/files/1/1408/4802/files/payment_icon_06_50xd524.png?v=1496323496" alt=""></a></li><li><a href="#"><img src="<?=base_url();?>fassets/files/1/1408/4802/files/payment_icon_07_50x160c.png?v=1496323505" alt=""></a></li><li><a href="#"><img src="<?=base_url();?>fassets/files/1/1408/4802/files/payment_icon_08_50xdd67.png?v=1496323512" alt=""></a></li></ul>
</div-->
      </div>
      
      
      <div class="pull-left">
        <div class="box-copyright">© 2017. <span>All Rights Reserved.</span></div>
      </div>
      
    
  </div>
</div>

  <a href="#" class="back-to-top">
    <span class="icon icon-keyboard_arrow_up"></span>
    <span class="text">Back to top</span>
  </a>
</footer>
<!--JS============================================================================================-->
	<script src="<?=base_url();?>fassets/bootstrap.min760d.js" type="text/javascript"></script>
	<script src="<?=base_url();?>fassets/slick.min760d.js" type="text/javascript"></script>
	<script src="<?=base_url();?>fassets/assets/themes_support/api.jquery-0ea851da22ae87c0290f4eeb24bc8b513ca182f3eb721d147c009ae0f5ce14f9.js" type="text/javascript"></script>
	<script src="<?=base_url();?>fassets/cart.api760d.js" type="text/javascript"></script>
	<div class="revolution_included"></div>
	<script src="<?=base_url();?>fassets/jquery.themepunch.tools.min760d.js" type="text/javascript"></script>
	<script src="<?=base_url();?>fassets/jquery.themepunch.revolution.min760d.js" type="text/javascript"></script>
	<script src="<?=base_url();?>fassets/moment-momenttimezone.min760d.js" type="text/javascript"></script>
	<script src="<?=base_url();?>fassets/jquery.plugin.min760d.js" type="text/javascript"></script>
    <script src="<?=base_url();?>fassets/jquery.countdown.min760d.js" type="text/javascript"></script>
	<script src="<?=base_url();?>fassets/instafeed.min760d.js" type="text/javascript"></script>
	<script src="<?=base_url();?>fassets/swatches760d.js" type="text/javascript"></script>
	<script src="<?=base_url();?>fassets/swatches_and_quickview760d.js" type="text/javascript"></script>
	<script src="<?=base_url();?>fassets/panelmenu760d.js" type="text/javascript"></script>
	<script src="<?=base_url();?>fassets/main760d.js" type="text/javascript"></script>
	<script src="<?=base_url();?>fassets/javascripts/currencies.js" type="text/javascript"></script>
	<script src="<?=base_url();?>fassets/jquery.currencies.min760d.js" type="text/javascript"></script>
	<script src="../apis.google.com/js/platform.js"></script>
	<style>
	    .active
	    {
	        border:0px!important;
	    }
	</style>