<!--
Au<!--
Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE HTML>
<html>
<head>
<link href="<?=base_url();?>css/bootstrap.css" rel="stylesheet" type="text/css" media="all"/>
<link href="<?=base_url();?>css/style.css" rel="stylesheet" type="text/css" media="all" />
<link href="<?=base_url();?>css/owl.carousel.css" rel="stylesheet">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<script src="<?=base_url();?>js/jquery.min.js"></script>

<!-- cart -->
		<script src="<?=base_url();?>js/simpleCart.min.js"> </script>
	<!-- cart -->
<script type="text/javascript" src="<?=base_url();?>js/bootstrap-3.1.1.min.js"></script>
<script src="<?=base_url();?>js/imagezoom.js"></script>

						<!-- FlexSlider -->
  <script defer src="<?=base_url();?>js/jquery.flexslider.js"></script>
<link rel="stylesheet" href="<?=base_url();?>css/flexslider.css" type="text/css" media="screen" />

<script>
// Can also be used with $(document).ready()
$(window).load(function() {
  $('.flexslider').flexslider({
    animation: "slide",
    controlNav: "thumbnails"
  });
});
</script>

<style>
    .active
    {
      
    }
    .active_size
    {
        
    }
    .modal-header {
    border-bottom: 0px solid #e5e5e5;
    min-height: 16.4286px;
    padding: 15px;
}
    </style>

</head>
<body>
	<!--header-->
		<?php
                require_once 'header_pro.php';
                ?>
			<!--header-->
	<div class="content">
		<div class="single">
			<div class="container">
				<div class="single-grids">
					 
                                    <?php
                                    foreach ($product_detail as $detail)
                                    {
                                                $id = $detail->id;
                                                $name = $detail->product_name;
                                                $description = $detail->product_description;
                                                $price = $detail->product_price;
                                                $image  =  $detail->product_image;       
                                    ?>
					<div class="col-md-4 single-grid">		
						<div class="flexslider">
							<ul class="slides">
							   <?php $all_images = $this->db->get_where('tbl_meta',array('ref_id'=> $id))->result_array(); 
                                            for($i=0; $i < count($all_images); $i++)
                                            {
                                            ?>
								<li data-thumb="<?=base_url().$all_images[$i]['link'];?>">
                                                                    <div class="thumb-image"> <img src="<?=base_url().$all_images[$i]['link'];?>" data-imagezoom="true" style="width: 100%; height: 425px;"> </div>
								</li>
								<?php } ?>
							</ul>
						</div>
					</div>	
					<div class="col-md-4 single-grid simpleCart_shelfItem">		
                                            <h3 style="text-transform: capitalize;"><?=$detail->product_name?></h3>
                                                <p><?=$detail->product_description?></p>
                        <script>
      
      
        </script>
                                                   
                                                
	
                                                        
                                                
                                                	<div class="galry">
								<div class="prices">
									<h5 class="item_price">Rs. <?=$detail->product_price;?></h5>
								</div>
								
								<div class="clearfix"></div>
							</div>
								
							<div class="btn_form">
                                                            
                                                            <form action="<?=base_url();?>cart/add" method="post" name="productform" onsubmit="return validateForm()">
                                                       <p class="qty"> Qty :  </p>
                                                        <input min="1" type="number" id="quantity" name="qty" value="1" class="form-control input-small">
                                          
                                                    <!--<input type="text" class="item_quantity" name="qty" value="1" />-->
                                                    <?php echo form_hidden('id', $id);
                                                    echo form_hidden('name', $name);
                                                    echo form_hidden('price', $price);
                                                    echo form_hidden('image', $image);
                                            ?> 
                                                    <button type="submit" class="add-cart item_add" name="action">ADD TO CART</button>
                                                                    
                                               <?php
//                                                echo form_close();
                                            ?>
                                                                </form>
                                                            
                                                            
                                                            
								<!--<a href="#" class="add-cart item_add">ADD TO CART</a>-->	
                                                                <br>
							</div>
							<div class="tag">
                                                            <p>Category : <a style="text-transform: capitalize; cursor: pointer;"> 
                                                                                <?php
                                                                                $cat  = $this->db->query('SELECT * FROM tbl_category WHERE id ='.$detail->category_id.' ');
                                                                                foreach ($cat->result() as $value) {
                                                                                 echo $value->category_name;   
                                                                                }
                                                                                ?>
                                                                                 </a></p>
								<!--<p>Tag : <a href="#"> Lorem ipsum </a></p>-->
							</div>
					</div>
                                 
					<div class="clearfix"> </div>
				</div>
			</div>
		</div>
<!-- collapse -->
		<div class="collpse">
		<div class="container">
		<div class="panel-group collpse" id="accordion" role="tablist" aria-multiselectable="true">
		  <div class="panel panel-default">
			<div class="panel-heading" role="tab" id="headingOne">
			  <h4 class="panel-title">
				<a style="color:#000;"  role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
				  Description
				</a>
			  </h4>
			</div>
			<div id="collapseOne" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingOne">
			  <div class="panel-body">
				<?=$detail->product_description?>
			  </div>
			</div>
		  </div>
		   
		</div>   <?php }?>
	</div>
</div>
<!-- collapse -->
		<div class="related-products">
			<div class="container">
				<h3>Related Products</h3>
				<div class="product-model-sec single-product-grids">
                                     <?php
                                        foreach ($related_product_detail as $post)
                                        { 
                                            foreach ($post as $data)
                                            { 

                                            if(!empty($data))
                                            {

                                                foreach ($data as $value)
                                                { 

                                                    $id = $value->id;
                                                    $name = $value->product_name;
                                                    $description = $value->product_description;
                                                    $price = $value->product_price;
                                                    $image  =  $value->product_image;                                            
                                            ?>
				
                                    
                                    
                                    	 <div class="product-grid "  >
						<div class="more-product"><span> </span></div>						
						<div class="product-img b-link-stripe b-animate-go  thickbox">
                                                    <img class=""   src="<?=base_url();?>/upload/product/<?=$value->id;?>/<?=$value->product_image;?>" style="width: 100%; height: 300px; cursor: pointer;"  alt="">
                                                    <div class="b-wrapper quicklook" id="<?=$value->id;?>" style="cursor: pointer;">
							<h4 class="b-animate b-from-left  b-delay03">							
							<button> + </button>
							</h4>
							</div>
						</div>
						<div class="product-info simpleCart_shelfItem">
							<div class="product-info-cust prt_name">
                                                            <h4 style="color: #333333; text-transform: capitalize; font-size: 18px;"><?=$value->product_name;?></h4>								
								<span class="item_price">Rs. <?=$value->product_price;?></span>
								
								<!--<input type="text" class="item_quantity" value="1" />-->
                                                            <!--<button type="submit" class="item_add items" name="action">View Look</button>-->  
                                              
                                                                
                                                                
								<!--<input type="button" class="item_add items" value="+">-->
								<div class="clearfix"> </div>
							</div>												
						</div>
					</div>
                                     <?php } }
                                                        else
                                                        {
                                                            echo "No Item Found!!";
                                                        }
                                                        
                                                            }
                                                    }?>
					<div class="clearfix"> </div>
				</div>
			</div>
		</div>
</div>
                        <div class="modal fade" id="header-modal" aria-hidden="true" ></div>
	<!--footer-->
		<?php
                require_once 'footer_pro.php';
                ?>
	<!--footer-->
        
			
</body>
</html>
<script type="text/javascript">
            
	
                    
                     
                         
                   
          
	</script>