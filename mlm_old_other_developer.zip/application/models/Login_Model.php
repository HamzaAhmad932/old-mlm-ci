<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Login_Model extends CI_Model {
    
        public function login($email,$password)
	{
            $this -> db -> select(' * ');
            $this -> db -> from('user_detail');
            $this -> db -> where('email', $email);
            $this -> db -> where('password', $password);
            $this -> db -> limit(1);
            $query = $this -> db -> get();
            return $query;
	}
      
        function verify($email, $password) 
        {
             
            $query=$this->db->query("SELECT * FROM tbl_customers WHERE email = '$email' AND password = '$password' limit 1 ");
            $result = $query->row_array();
            $resultx = $query->result_array();
            if ($query->num_rows() > 0)
            {
                if($resultx[0]['status'] == 'active' || $resultx[0]['status']!= 'active' && $resultx[0]['customer_id'] == 2 || $resultx[0]['status']!= 'active' && $resultx[0]['customer_id'] == 3  )
                {
                    return($result);
                }
                else
                {
                    return false;
                }
            }
            else 
            {
                return false;
            }
        }
        
        function add() 
        {
            $this->db->set('created_date',date('Y-m-d H:i:s'));
            
            $this->db->set('email', $this->input->post('email'));

            $this->db->set('first_name', $this->input->post('firstname'));

            $this->db->set('last_name', $this->input->post('lastname'));

            $this->db->set('phone', $this->input->post('phone'));

            $this->db->set('password', $this->input->post('password'));
            $refID = $this->input->post('refferal_id');
            $ref_not_then = $this->db->get('tbl_default_id')->result_array();
            if(empty($refID))
            {
                $dataMembers = $this->db->get_where('tbl_customers',array('status'=>'active'))->result_array();
                    for($x=0;$x<count($dataMembers); $x++)
                    {
                        $this->db->order_by('customer_id','ASC');
                        //get harargy of 2 inactive users
                        $usx = $this->db->get_where('tbl_customers',array('refferal_id'=>$dataMembers[$x]['customer_id'],'status'=>'inactive'))->result_array();
                        if(count($usx) > 1)
                        {
                            $usdx = $this->db->get_where('tbl_customers',array('refferal_id'=>$dataMembers[$x]['customer_id'],'status'=>'active'))->result_array();
                            if(count($usdx) == 0)
                            {
                                $refID = $dataMembers[$x]['customer_id'];
                                break;
                            }
                        }
                    }
            }
            echo $refID;
            if(empty($refID))
                {
                    $refID = $ref_not_then[0]['default_id'];
                }
            $this->db->set('refferal_id', $refID);
            if($this->db->insert('tbl_customers'))
            $response=$this->db->insert_id();
            $this->db->order_by('id','desc');
            $this->db->limit(2);
            $get_node = $this->db->get('tbl_refferal')->result_array();
            $new_node = 0;
            $node1 = 0;
            $node2 = 0;
            for($n=0;$n < count($get_node); $n++)
            {
                if($n == 0)
                { 
                   $node1 = $get_node[$n]['node_of'];
                }
                if($n == 1)
                { 
                   $node2 = $get_node[$n]['node_of'];
                }
                if($node1 == $node2)
                {
                    $new_node = $node1 + 1;
                }
                else
                {
                    $new_node = $node1;
                }
            }
            $numberofMembs = $this->db->get_where('tbl_refferal', array('refferral_id'=>$refID))->result_array();
            $numberofMembsC = count($numberofMembs);
            $numberofMembsC = $numberofMembsC + 1;
            $reff_table = array('customer_id' =>$response, 'refferral_id'=>$refID,'member_num'=>$numberofMembsC,'node_of'=>$new_node);
            $this->db->insert('tbl_refferal',$reff_table);
        }
  
       
}