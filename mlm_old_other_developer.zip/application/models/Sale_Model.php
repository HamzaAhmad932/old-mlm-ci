<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Sale_Model extends CI_Model {
    
        function __construct() {
        parent::__construct();
		$this->tablename	= $this->session->userdata('table_id').'tbl_sales';
		$this->tablesubcategory = $this->session->userdata('table_id').'tbl_subcategory';
		$this->tablecategory = $this->session->userdata('table_id').'tbl_category';
        }
        
        
        function get_list() {
            $this->db->select(" *, ");
            $this->db->from($this->tablename);
            //$this->db->where('shipped_status','0');
            $query = $this->db->get();
            return $query->result();
        }
        function Buyer_Name() {
            $this->db->select(" *, ");
            $this->db->from($this->tablename);
            $this->db->where('shipped_status','0');
            $query = $this->db->get();
            return $query->result();
        }
        function getAllHistoryRecord($buyer_name,$start_date,$end_date,$create) {
                $this->db->select($this->tablename.'.buyer_name,grand_amount,id,issue_date,due_date,cash_discount,total_quantity,shipped_status,created_by');
	        if($buyer_name)
                $this->db->where($this->tablename.'.buyer_name =',$buyer_name);
		if($start_date)
		$this->db->where($this->tablename.'.issue_date >=',$start_date);
		if($end_date)
		$this->db->where($this->tablename.'.issue_date <=',$end_date);
		if(isset($create))
        	$this->db->where($this->tablename.'.created_by =',$create);
        	$this->db->where($this->tablename.'.shipped_status','0');
                $query = $this->db->get($this->tablename);
                        //echo $this->db->last_query(); die;
                $result = $query->result();
                return $result;
         }
        
        function getAllHistoryRecordStatus($buyer_name,$start_date,$end_date,$create) {
                $this->db->select($this->tablename.'.buyer_name,grand_amount,id,issue_date,due_date,cash_discount,total_quantity,shipped_status,created_by');
	        if($buyer_name)
                $this->db->where($this->tablename.'.buyer_name =',$buyer_name);
		if($start_date)
		$this->db->where($this->tablename.'.issue_date >=',$start_date);
		if($end_date)
		$this->db->where($this->tablename.'.issue_date <=',$end_date);
		if(isset($create))
        	$this->db->where($this->tablename.'.created_by =',$create);
        	$this->db->where($this->tablename.'.shipped_status','1');
                $query = $this->db->get($this->tablename);
                        //echo $this->db->last_query(); die;
                $result = $query->result();
                return $result;
         }
        
          function Buyer_Name_Status() {
            $this->db->select(" *, ");
            $this->db->from($this->tablename);
            $this->db->where('shipped_status','1');
            $query = $this->db->get();
            return $query->result();
        }
        
        function shipped() {
            $this->db->select(" *, ");
            $this->db->from($this->tablename);
            $this->db->where('shipped_status','1');
            $query = $this->db->get();
            return $query->result();
        }
        function SaleDetail($id) {
            $this->db->select(" *,tbl_sales_detail.quantity,tbl_sales_detail.color_id,tbl_sales_detail.size_id");
            $this->db->from('tbl_sales_detail');
            $this->db->join('tbl_products', 'tbl_products.product_code = tbl_sales_detail.product_code');
            $this->db->join('tbl_checkout', 'tbl_checkout.sale_id = tbl_sales_detail.sale_id');
            $this->db->where('tbl_sales_detail.sale_id',$id);
            $query = $this->db->get();
//           print_r($this->db->last_query()); 
//           die;
            return $query->result();
        }
        function Address_Detail($id) {
            $this->db->select(" * ");
            $this->db->from('tbl_checkout');
            $this->db->where('sale_id',$id);
            $query = $this->db->get();
//           print_r($this->db->last_query()); 
//           die;
            return $query->result();
        }
        function Deliver_Sale($id) {
            $this->db->select(" * ");
            $this->db->from('tbl_sales');
            $this->db->where('id',$id);
            $query = $this->db->get();
            return $query->result();
        }
        function SaleStatus($id) {
            $this->db->set('shipped_status','1');
            $this->db->where('id',$id);
            $this->db->update('tbl_sales');
           
        }
        function SaleStatusComplete($id) {
            //order id   $id
            //GET data
            $CI =& get_instance();
            //extra percentage comission
            $extra_Comisson = $CI->Sale_Model->allFerreralTreecomission($id);
            $Orders_Pending = $this->db->get_where('tbl_sales',array('id'=> $id, 'status'=> 1))->result_array();
            for($o=0; $o< count($Orders_Pending); $o++)
            {
                //get order meta
                $calculated_order_pv = 0;
                $calculated_order_bv = 0;
                    $data_SALES = $this->db->get_where('tbl_sales_detail',array('sale_id'=>$Orders_Pending[$o]['id']))->result_array();
                        for($x=0; $x < count($data_SALES); $x++)
                        {
                           //PV of Order total calculation
                           $calculated_order_pv = $calculated_order_pv + $data_SALES[$x]['pv'];
                           $calculated_order_bv = $calculated_order_bv + $data_SALES[$x]['bv'];
                        }
                //total Share
                $total_share = $calculated_order_bv;
                $total_basic = $calculated_order_pv;
                //direct reffer
                    $order_refferer = $this->db->get_where('tbl_customers',array('customer_id'=> $Orders_Pending[$o]['buyer_id']))->result_array();
                //get last 10 chain
                $buyyer_ref_chain = $this->db->get_where('tbl_refferal',array('customer_id'=>$Orders_Pending[$o]['buyer_id']))->result_array();
                //print_r($Orders_Pending[$o]['buyer_id']);
                //print_r($buyyer_ref_chain);
                $total_chain_members = 0 ;
                //$live_customers = 0;
                $bacix = $this->db->get_where('tbl_comission_dist')->result_array();
                    for($n=0; $n< 9 ; $n++)
                    {
                        //first user reffered
                        if($n == 0)
                            {
                            $one_upper_then_first = $this->db->get_where('tbl_refferal',array('customer_id'=>$buyyer_ref_chain[0]['refferral_id']))->result_array();
                            //print_r($one_upper_then_first[0]['customer_id']);
                                if(!empty($one_upper_then_first))
                                {
                                    $comission1 = $CI->Sale_Model->customer_level($one_upper_then_first[0]['customer_id']);
                                    $comission1b = $bacix[0]['basic'];
                                    $comission1bo = $comission1['booster_com'];
                                    $CI->Sale_Model->normalized_comission_deliver($comission1b,$comission1bo, $extra_Comisson['extra_Basic'], $extra_Comisson['extra_booster'],$total_basic, $total_share, $one_upper_then_first[0]['customer_id']);
                                    $total_chain_members = $total_chain_members + 1; 
                                    echo "<br>";
                                }
                            }
                        //if n = 1 get second user reff
                        if($n == 1)
                        {
                            $one_upper_then_second = $this->db->get_where('tbl_refferal',array('customer_id'=>$one_upper_then_first[0]['refferral_id']))->result_array();
                            //print_r($one_upper_then_second[0]['customer_id']);
                            $comission2 = $CI->Sale_Model->customer_level($one_upper_then_second[0]['customer_id']);
                            $comission2b = $bacix[1]['basic'];
                            $comission2bo = $comission2['booster_com'];
                            $CI->Sale_Model->normalized_comission_deliver($comission2b,$comission2bo, $extra_Comisson['extra_Basic'], $extra_Comisson['extra_booster'],$total_basic, $total_share, $one_upper_then_second[0]['customer_id']);
                            $total_chain_members = $total_chain_members + 1;
                            echo "<br>";
                        }
                        //if n = 2 get third user reff
                        if($n == 2)
                        {
                            $one_upper_then_third = $this->db->get_where('tbl_refferal',array('customer_id'=>$one_upper_then_second[0]['refferral_id']))->result_array();
                            //print_r($one_upper_then_third[0]['customer_id']);
                            $comission3 = $CI->Sale_Model->customer_level($one_upper_then_third[0]['customer_id']);
                            $comission3b = $bacix[2]['basic'];
                            $comission3bo = $comission3['booster_com'];
                            $CI->Sale_Model->normalized_comission_deliver($comission3b,$comission3bo, $extra_Comisson['extra_Basic'], $extra_Comisson['extra_booster'],$total_basic, $total_share, $one_upper_then_third[0]['customer_id']);
                            $total_chain_members = $total_chain_members + 1;
                            echo "<br>";
                        }
                        //if n = 3 get fourth user reff
                        if($n == 3)
                        {
                            $one_upper_then_fourth = $this->db->get_where('tbl_refferal',array('customer_id'=>$one_upper_then_third[0]['refferral_id']))->result_array();
                            //print_r($one_upper_then_fourth[0]['customer_id']);
                            $comission4 = $CI->Sale_Model->customer_level($one_upper_then_fourth[0]['customer_id']);
                            $comission4b = $bacix[3]['basic'];
                            $comission4bo = $comission4['booster_com'];
                            $CI->Sale_Model->normalized_comission_deliver($comission4b,$comission4bo, $extra_Comisson['extra_Basic'], $extra_Comisson['extra_booster'],$total_basic, $total_share, $one_upper_then_fourth[0]['customer_id']);
                            $total_chain_members = $total_chain_members + 1;
                            echo "<br>";
                        }
                        //if n = 4 get fifth user reff
                        if($n == 4)
                        {
                            $one_upper_then_fifth = $this->db->get_where('tbl_refferal',array('customer_id'=>$one_upper_then_fourth[0]['refferral_id']))->result_array();
                            //print_r($one_upper_then_fifth[0]['customer_id']);
                            $comission5 = $CI->Sale_Model->customer_level($one_upper_then_fifth[0]['customer_id']);
                            $comission5b = $bacix[4]['basic'];
                            $comission5bo = $comission5['booster_com'];
                            //$CI->Sale_Model->normalized_comission_deliver($comission5, $extra_Comisson, [0]['customer_id'], $total_share);
                            $CI->Sale_Model->normalized_comission_deliver($comission5b,$comission5bo, $extra_Comisson['extra_Basic'], $extra_Comisson['extra_booster'],$total_basic, $total_share, $one_upper_then_fifth[0]['customer_id']);
                            $total_chain_members = $total_chain_members + 1;
                            echo "<br>";
                        }
                        //if n = 5 get sixth user reff
                        if($n == 5)
                        {
                            $one_upper_then_sixth = $this->db->get_where('tbl_refferal',array('customer_id'=>$one_upper_then_fifth[0]['refferral_id']))->result_array();
                            //print_r($one_upper_then_sixth[0]['customer_id']);
                            $comission6 = $CI->Sale_Model->customer_level($one_upper_then_sixth[0]['customer_id']);
                            $comission6b = $bacix[5]['basic'];
                            $comission6bo = $comission6['booster_com'];
                            $CI->Sale_Model->normalized_comission_deliver($comission6b,$comission6bo, $extra_Comisson['extra_Basic'], $extra_Comisson['extra_booster'],$total_basic, $total_share, $one_upper_then_sixth[0]['customer_id']);
                            $total_chain_members = $total_chain_members + 1;
                            echo "<br>";
                        }
                        //if n = 6 get seventh user reff
                        if($n == 6)
                        {
                            $one_upper_then_seventh = $this->db->get_where('tbl_refferal',array('customer_id'=>$one_upper_then_sixth[0]['refferral_id']))->result_array();
                            //print_r($one_upper_then_seventh[0]['customer_id']);
                            $comission7 = $CI->Sale_Model->customer_level($one_upper_then_seventh[0]['customer_id']);
                            $comission7b = $bacix[6]['basic'];
                            $comission7bo = $comission7['booster_com'];
                            $CI->Sale_Model->normalized_comission_deliver($comission7b,$comission7bo, $extra_Comisson['extra_Basic'], $extra_Comisson['extra_booster'],$total_basic, $total_share, $one_upper_then_seventh[0]['customer_id']);
                            
                            $total_chain_members = $total_chain_members + 1;
                            
                            echo "<br>";
                        }
                        //if n = 7 get eighth user reff
                        if($n == 7)
                        {
                            $one_upper_then_eighth = $this->db->get_where('tbl_refferal',array('customer_id'=>$one_upper_then_seventh[0]['refferral_id']))->result_array();
                            //print_r($one_upper_then_eighth[0]['customer_id']);
                            $comission8 = $CI->Sale_Model->customer_level($one_upper_then_eighth[0]['customer_id']);
                            $comission8b = $bacix[7]['basic'];
                            $comission8bo = $comission8['booster_com'];
                            $CI->Sale_Model->normalized_comission_deliver($comission8b,$comission8bo, $extra_Comisson['extra_Basic'], $extra_Comisson['extra_booster'],$total_basic, $total_share, $one_upper_then_eighth[0]['customer_id']);
                            
                            $total_chain_members = $total_chain_members + 1;
                            echo "<br>";
                        }
                        //if n = 8 get ninth user reff
                        if($n == 8)
                        {
                            $one_upper_then_ninth = $this->db->get_where('tbl_refferal',array('customer_id'=>$one_upper_then_eighth[0]['refferral_id']))->result_array();
                            //print_r($one_upper_then_ninth[0]['customer_id']);
                            $comission9 = $CI->Sale_Model->customer_level($one_upper_then_ninth[0]['customer_id']);
                            $comission9b = $bacix[8]['basic'];
                            $comission9bo = $comission9['booster_com'];
                            $CI->Sale_Model->normalized_comission_deliver($comission9b,$comission9bo, $extra_Comisson['extra_Basic'], $extra_Comisson['extra_booster'],$total_basic, $total_share, $one_upper_then_ninth[0]['customer_id']);
                            $total_chain_members = $total_chain_members + 1;
                            echo "<br>";
                        }
                        //if n = 9 get tenth user reff
                        
                            $one_last = $this->db->get_where('tbl_refferal',array('customer_id'=>$one_upper_then_ninth[0]['refferral_id']))->result_array();
                            //print_r($one_last[0]['customer_id']);
                            $comission10 = $CI->Sale_Model->customer_level($one_last[0]['customer_id']);
                            $comission10b = $bacix[9]['basic'];
                            $comission10bo = $comission10['booster_com'];
                            $CI->Sale_Model->normalized_comission_deliver($comission10b,$comission10bo, $extra_Comisson['extra_Basic'], $extra_Comisson['extra_booster'],$total_basic, $total_share, $one_last[0]['customer_id']);
                            
                            $total_chain_members = $total_chain_members + 1;
                            //echo "<br>".$one_last[0]['customer_id'];
                        //end of counter chain for loop
                        
                    }
                    
            }

           
            //danger below not to edit below
            $this->db->set('shipped_status','3');
            $this->db->where('id',$id);
            $this->db->update('tbl_sales');
        }
        //get all commission array('extra_Basic'=>$comissionIS_basic , 'extra_booster'=>$extraComissionDivide);
         function allFerreralTreecomission($id) 
         {
            //order id   $id
            //GET data
            $CI =& get_instance();
            $Orders_Pending = $this->db->get_where('tbl_sales',array('id'=> $id, 'status'=> 1))->result_array();
            for($o=0; $o< count($Orders_Pending); $o++)
            {
                //direct reffer
                //get last 10 chain
                $buyyer_ref_chain = $this->db->get_where('tbl_refferal',array('customer_id'=>$Orders_Pending[$o]['buyer_id']))->result_array();
                $total_chain_members = 0 ;
                $comission1b  = 0;
                $comission2b  = 0;
                $comission3b  = 0;
                $comission4b  = 0;
                $comission5b  = 0;
                $comission6b  = 0;
                $comission7b  = 0;
                $comission8b  = 0;
                $comission9b  = 0;
                $comission10b = 0;
                $comission1bo  = 0;
                $comission2bo  = 0;
                $comission3bo  = 0;
                $comission4bo  = 0;
                $comission5bo  = 0;
                $comission6bo  = 0;
                $comission7bo  = 0;
                $comission8bo  = 0;
                $comission9bo  = 0;
                $comission10bo = 0;
                $bacix = $this->db->get_where('tbl_comission_dist')->result_array();
                    for($n=0; $n< 10 ; $n++)
                    {
                        //first user reffered
                        if($n == 0 && !empty($buyyer_ref_chain[0]['node_of']))
                        {
                            $one_upper_then_first = $this->db->get_where('tbl_refferal',array('customer_id'=>$buyyer_ref_chain[0]['refferral_id']))->result_array();
                            $comission1 = $CI->Sale_Model->customer_level($one_upper_then_first[0]['customer_id']);
                            $comission1b = $bacix[0]['basic'];
                            $comission1bo = $comission1['booster_com'];
                            //echo $comission1b;
                            $total_chain_members = $total_chain_members + 1; 
                        }
                        //if n = 1 get second user reff
                        if($n == 1 && !empty($one_upper_then_first[0]['refferral_id']))
                        {
                            $one_upper_then_second = $this->db->get_where('tbl_refferal',array('customer_id'=>$one_upper_then_first[0]['refferral_id']))->result_array();
                            $comission2 = $CI->Sale_Model->customer_level($one_upper_then_second[0]['customer_id']);
                            $comission2b = $bacix[1]['basic'];
                            $comission2bo = $comission2['booster_com'];
                            $total_chain_members = $total_chain_members + 1;
                        }
                        //if n = 2 get third user reff
                        if($n == 2 && !empty($one_upper_then_second[0]['refferral_id']))
                        {
                            $one_upper_then_third = $this->db->get_where('tbl_refferal',array('customer_id'=>$one_upper_then_second[0]['refferral_id']))->result_array();
                            $comission3 = $CI->Sale_Model->customer_level($one_upper_then_third[0]['customer_id']);
                            $comission3b = $bacix[2]['basic'];
                            $comission3bo = $comission3['booster_com'];
                            $total_chain_members = $total_chain_members + 1;
                        }
                        //if n = 3 get fourth user reff
                        if($n == 3 && !empty($one_upper_then_third[0]['refferral_id']))
                        {
                            $one_upper_then_fourth = $this->db->get_where('tbl_refferal',array('customer_id'=>$one_upper_then_third[0]['refferral_id']))->result_array();
                            $comission4 = $CI->Sale_Model->customer_level($one_upper_then_fourth[0]['customer_id']);
                            $comission4b = $bacix[3]['basic'];
                            $comission4bo = $comission4['booster_com'];
                            $total_chain_members = $total_chain_members + 1;
                        }
                        //if n = 4 get fifth user reff
                        if($n == 4 && !empty($one_upper_then_fourth[0]['refferral_id']))
                        {
                            $one_upper_then_fifth = $this->db->get_where('tbl_refferal',array('customer_id'=>$one_upper_then_fourth[0]['refferral_id']))->result_array();
                            $comission5 = $CI->Sale_Model->customer_level($one_upper_then_fifth[0]['customer_id']);
                            $comission5b = $bacix[4]['basic'];
                            $comission5bo = $comission5['booster_com'];
                            $total_chain_members = $total_chain_members + 1;
                        }
                        //if n = 5 get sixth user reff
                        if($n == 5 && !empty($one_upper_then_fifth[0]['refferral_id']))
                        {
                            $one_upper_then_sixth = $this->db->get_where('tbl_refferal',array('customer_id'=>$one_upper_then_fifth[0]['refferral_id']))->result_array();
                            $comission6 = $CI->Sale_Model->customer_level($one_upper_then_sixth[0]['customer_id']);
                            $comission6b = $bacix[5]['basic'];
                            $comission6bo = $comission6['booster_com'];
                            $total_chain_members = $total_chain_members + 1;
                        }
                        //if n = 6 get seventh user reff
                        if($n == 6 && !empty($one_upper_then_sixth[0]['refferral_id']))
                        {
                            $one_upper_then_seventh = $this->db->get_where('tbl_refferal',array('customer_id'=>$one_upper_then_sixth[0]['refferral_id']))->result_array();
                            $comission7 = $CI->Sale_Model->customer_level($one_upper_then_seventh[0]['customer_id']);
                            $comission7b = $bacix[6]['basic'];
                            $comission7bo = $comission7['booster_com'];
                            $total_chain_members = $total_chain_members + 1;
                        }
                        //if n = 7 get eighth user reff
                        if($n == 7 && !empty($one_upper_then_seventh[0]['refferral_id']))
                        {
                            $one_upper_then_eighth = $this->db->get_where('tbl_refferal',array('customer_id'=>$one_upper_then_seventh[0]['refferral_id']))->result_array();
                            $comission8 = $CI->Sale_Model->customer_level($one_upper_then_eighth[0]['customer_id']);
                            $comission8b = $bacix[7]['basic'];
                            $comission8bo = $comission8['booster_com'];
                            $total_chain_members = $total_chain_members + 1;
                        }
                        //if n = 8 get ninth user reff
                        if(!empty($one_upper_then_eighth[0]['refferral_id']))
                        {
                            $one_upper_then_ninth = $this->db->get_where('tbl_refferal',array('customer_id'=>$one_upper_then_eighth[0]['refferral_id']))->result_array();
                            $comission9 = $CI->Sale_Model->customer_level($one_upper_then_ninth[0]['customer_id']);
                            $comission0b = $bacix[8]['basic'];
                            $comission9bo = $comission9['booster_com'];
                            $total_chain_members = $total_chain_members + 1;
                        }
                        //if n = 9 get tenth user reff
                        if(!empty($one_upper_then_ninth))
                        {
                            $one_last = $this->db->get_where('tbl_refferal',array('customer_id'=>$one_upper_then_ninth[0]['refferral_id']))->result_array();
                            $comission10 = $CI->Sale_Model->customer_level($one_last[0]['customer_id']);
                            $comission10b = $bacix[9]['basic'];
                            $comission10bo = $comission10['booster_com'];
                            $total_chain_members = $total_chain_members + 1;
                        }
                        //end of counter chain for loop
                    }
                    $comissionIS_basic = $comission1b + $comission2b + $comission3b + $comission4b + $comission5b + $comission6b + $comission7b + $comission8b + $comission9b + $comission10b;
                    $comissionIS_booster = $comission1bo + $comission2bo + $comission3bo + $comission4bo + $comission5bo + $comission6bo + $comission7bo + $comission8bo + $comission9bo + $comission10bo;
                    
                    if(($comissionIS_booster - 100) == 0)
                    {
                        $extraComissionDivide = 0;
                    }
                    else if(($comissionIS_booster - 100) > 0)
                    {
                       $extraComission = $comissionIS_booster - 100;
                       $extraComissionDivide = $extraComission / $total_chain_members;
                       //return $extraComissionDivide;
                    }if (($comissionIS_booster - 100) < 0)
                    {
                        $extraComissionDivide = 0;
                    }
                    if(($comissionIS_basic - 100) == 0)
                    {
                        $extraComissionDivideBasic = 0;
                    }
                    else if(($comissionIS_basic - 100) > 0)
                    {
                       $extraComission = $comissionIS_basic - 100;
                       $extraComissionDivideBasic = $extraComission / $total_chain_members;
                       //return $extraComissionDivide;
                    }if (($comissionIS_basic - 100) < 0)
                    {
                        $extraComissionDivideBasic = 0;
                    }
                     return array('extra_Basic'=>$extraComissionDivideBasic , 'extra_booster'=>$extraComissionDivide);
            }
        }
        // end get all comission
        //get customer level array('basic_com'=> $comission_of_customer[0]['basic'],'booster_com'=>$Counter_boosterVolume);
         public function customer_level($customer_id)
            {
                //echo $customer_id;
                $customer_id_record = $this->db->get_where('tbl_customers',array('customer_id'=>$customer_id,'status'=> 'active'))->result_array();
                if(!empty($customer_id_record))
                {
                    $comission_of_customer = $this->db->get_where('tbl_comission_dist',array('level_num'=>$customer_id_record[0]['level']))->result_array();   
                    $comission_criterion_customer = $this->db->get_where('tbl_levelStandard',array('level_standard'=>$customer_id_record[0]['level']))->result_array();
                   //print_r($customer_id_record[0]['level']);
                   if(!empty($comission_criterion_customer))
                   {
                        if($comission_criterion_customer[0]['name_pkg']=="basic")
                        {
                            $Counter_boosterVolume = 0;
                            $total_comission_array = array('basic_com'=> $comission_of_customer[0]['basic'],'booster_com'=>$Counter_boosterVolume);
                            return $total_comission_array; 
                        }
                        if($comission_criterion_customer[0]['name_pkg']=="standard")
                        {
                            $Counter_boosterVolume = 0;
                            $Counter_boosterVolume = $comission_of_customer[0]['standard'];
                            $total_comission_array = array('basic_com'=> $comission_of_customer[0]['basic'],'booster_com'=>$Counter_boosterVolume);
                            return $total_comission_array; 
                        }
                        if($comission_criterion_customer[0]['name_pkg']=="silver")
                        {
                            $Counter_boosterVolume = 0;
                            $Counter_boosterVolume = $comission_of_customer[0]['standard'] + $comission_of_customer[0]['silver'];
                            $total_comission_array = array('basic_com'=> $comission_of_customer[0]['basic'],'booster_com'=>$Counter_boosterVolume);
                            return $total_comission_array; 
                        }
                        if($comission_criterion_customer[0]['name_pkg']=="gold")
                        {
                            $Counter_boosterVolume = 0;
                            $Counter_boosterVolume = $comission_of_customer[0]['standard'] + $comission_of_customer[0]['silver'] + $comission_of_customer[0]['gold'];
                            $total_comission_array = array('basic_com'=> $comission_of_customer[0]['basic'],'booster_com'=>$Counter_boosterVolume);
                            return $total_comission_array; 
                        }
                        if($comission_criterion_customer[0]['name_pkg']=="diamond")
                        {
                            $Counter_boosterVolume = 0;
                            $Counter_boosterVolume = $comission_of_customer[0]['standard'] + $comission_of_customer[0]['silver']+ $comission_of_customer[0]['gold'] + $comission_of_customer[0]['diamond'];
                            $total_comission_array = array('basic_com'=> $comission_of_customer[0]['basic'],'booster_com'=>$Counter_boosterVolume);
                            return $total_comission_array; 
                        }
                   }
                }
                else
                {
                    return 0;
                }
            }
            public function normalized_comission_deliver($comission_basic,$comission_booster,$ext_basic,$ext_booster,$total_basic,$total_booster, $c_id)
            {
                if($comission_basic != 0  && !empty($c_id) || !empty($comission_basic) && !empty($c_id))
                {
                    $percent_basic = $comission_basic;
                    $BasicPriceMoney = ($percent_basic / 100) * $total_basic;
                    //echo $c_id."<br>";
                    $if2mems = $this->db->get_where('tbl_refferal',array('refferral_id'=>$c_id))->result_array();
                    //echo count($if2mems);
                    if(count($if2mems) > 1)
                    {
                        $this->db->insert('tbl_earnings',array('wallet' => $BasicPriceMoney,'customer_id'=>$c_id, 'date'=> date('d M Y')));
                    }
                }
                if($comission_booster != 0 || !empty($comission_booster))
                {
                    $if2mems = $this->db->get_where('tbl_refferal',array('refferral_id'=>$c_id))->result_array();
                    $percent_booster = $comission_booster - $ext_basic;
                    $BoosterPriceMoney = ($percent_booster / 100) * $total_booster;
                    if(count($if2mems) > 1)
                    {
                        $this->db->insert('tbl_earnings',array('wallet' => $BoosterPriceMoney,'customer_id'=>$c_id, 'date'=> date('d M Y')));
                    }
                }
            }
        function SaleStatusCancel($id) {
            $this->db->set('shipped_status','2');
            $this->db->where('id',$id);
            $this->db->update('tbl_sales');
           
        }
}