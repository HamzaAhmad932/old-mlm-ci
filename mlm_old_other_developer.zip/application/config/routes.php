<?php
defined('BASEPATH') OR exit('No direct script access allowed');
//for mlm users
$route['mlm-home-user'] = 'mlm_user';
$route['request-payout'] = 'mlm_user/request_payout';
$route['payOut'] = 'mlm_user/payOut';
$route['find-orders'] ='mlm_user/find_orders';
$route['i-reffered'] = 'mlm_user/i_reffered';
$route['my-tree'] = 'mlm_user/draw_tree';
$route['my-tree-extended/(:num)/(:num)'] = 'mlm_user/extend_tree/$1/$2';
$route['customer-tree/(:num)/(:num)'] = 'admin/dashboard/tree_company_user/$1/$2';
//

$route['account/payout'] = 'admin/sale/payout';
$route['account/produc-list'] = 'admin/product';
$route['account/product-add'] = 'admin/product/product_add';
$route['account/signle-product-edit'] = 'admin/product/product_edit';
$route['account/product_edit_submit'] = 'admin/product/product_edit_submit';
$route['account/product-edit/(:num)'] = 'admin/product/get_product_edit/$1';
$route['account/product/product-code'] = 'admin/product/product_code';
$route['account/product-status/(:num)/(:num)'] = 'admin/product/ProductStatus/$1/$2';

$route['account/subcategory_view'] = 'admin/product/subcategory_view';
$route['account/product-delete/(:num)'] = 'admin/product/deleteProduct/$1';
$route['account/product-detail'] = 'admin/product/ProductDetail';

/*----------- For Sale Page --------------------------------------------- */
$route['account/sale-list'] = 'admin/sale';
$route['account/sale-detail/(:num)'] = 'admin/sale/SaleDetail/$1';
$route['account/sale-status/(:num)'] = 'admin/sale/SaleStatus/$1';
$route['account/sale-statusc/(:num)'] = 'admin/sale/SaleStatusCancel/$1';
$route['account/sale-statuscomp/(:num)'] = 'admin/sale/SaleStatusComplete/$1';
$route['account/sale-list-shipped'] = 'admin/sale/shipped';

/*----------- For Category Page --------------------------------------------- */
$route['account/category-add'] = 'admin/category/category_add';
$route['account/category'] = 'admin/category';
$route['account/edit-category/(:num)'] = 'admin/category/editCategory/$1';
$route['account/category-delete/(:num)'] = 'admin/category/deleteCategory/$1';
$route['account/category-status/(:num)/(:num)'] = 'admin/category/CategoryStatus/$1/$2';

/*----------- For Sub Category Page --------------------------------------------- */
$route['account/add-subcategory/(:num)'] = 'admin/category/addSubCategory/$1';
$route['account/view-subcategory/(:num)']	= 'admin/category/viewSubCategory/$1';
$route['account/edit-subcategory/(:num)']	= 'admin/category/editSubCategory/$1';
$route['account/sub-category-delete/(:num)']	= 'admin/category/SubCategoryDelete/$1';

/*----------- For Slidder --------------------------------------------- */
$route['account/add-slider'] = 'admin/slider/addSlider';
$route['account/list-slider'] = 'admin/slider';
$route['account/slider-delete/(:num)'] = 'admin/slider/DeleteSlider/$1';

/*----------- For Customer Page --------------------------------------------- */
$route['account/customer-list'] = 'admin/customer';
$route['account/cutomer-delete/(:num)'] = 'admin/customer/DeleteCustomer/$1';
/*----------- For user Page --------------------------------------------- */


$route['mobile-shop'] = 'dashboard/mobile-shop';
$route['cart'] = 'dashboard/cart';
$route['product-detail/(:num)'] = 'dashboard/product-detail/$1';
$route['add'] = 'dashboard/add';
$route['update-cart'] = 'dashboard/update_cart';
$route['clear-cart'] = 'cart/remove/all';
$route['signle-cart'] = 'dashboard/single_product_add_to_cart';

/*----------- Admin --------------------------------------------- */
$route['account/login'] = 'admin/login_controllers';
$route['account/dashboard'] = 'admin/dashboard';
$route['account/new-admin'] = 'admin/newadmin/admin_add';
$route['account/admin-list'] = 'admin/newadmin';
$route['account/admin-delete/(:num)'] = 'admin/newadmin/DeleteAdmin/$1';

/*----------- user product --------------------------------------------- */
$route['Products']	= 'product/allProductLists/';
$route['ProductList/(:num)']	= 'product/allProductList/$1';
$route['ProductList/(:num)/(:num)/(:num)']	= 'product/allProductList/$1/$2';
$route['ProductDetail/(:num)']	= 'product/oneProductdetail/$1';
/*----------- Wishlist --------------------------------------------- */
$route['delete-wishlist/(:num)']	= 'wishlist/DeleteWishlist/$1';
$route['category/(:num)']	= 'categorymenu/index/$1';

/*----------- Shipping --------------------------------------------- */
$route['shipping']	= 'dashboard/shipping';
$route['term']	= 'dashboard/term';
$route['faqs']	= 'dashboard/faqs';

/*----------- Color --------------------------------------------- */
$route['account/color-add'] = 'admin/color/color_add';
$route['account/color'] = 'admin/color';
$route['account/edit-color/(:num)'] = 'admin/color/editColor/$1';
$route['account/color-delete/(:num)'] = 'admin/color/deletecolor/$1';

/*----------- Size --------------------------------------------- */
$route['account/size-add'] = 'admin/size/size_add';
$route['account/size'] = 'admin/size';
$route['account/size-color/(:num)'] = 'admin/size/editSize/$1';
$route['account/size-delete/(:num)'] = 'admin/size/deleteSize/$1';

//$route['default_controller'] = 'ehome';

$route['default_controller'] = 'dashboard';
$route['404_override'] = '';
$route['translate_uri_dashes'] = true;

