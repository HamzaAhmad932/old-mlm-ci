<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Mlm_user extends CI_Controller {

        public function __construct()
	{
            parent::__construct();
            //load model
            //$this->load->model('Dashboard_Model');
            //$this->load->model('Category_Model');
            //$this->load->model('Subcategory_Model');
            //$this->load->model('Product_Model',"product_model");
            //$this->load->library('cart');
            $this->load->helper('url');  
            $this->load->helper('form');  
            $this->load->library('session');
            $this->load->database();
            $this->load->library('encrypt');
            //$this->cart->product_name_rules = '[:print:]';
        }


        public function index()
        {
            if(isset($_SESSION['userid']))
            {
                $data['reffered']  = $this->db->get_where('tbl_refferal',array('refferral_id'=>$_SESSION['userid']))->result_array();
                $data['meta']      = $this->db->get_where('tbl_customers',array('customer_id'=>$_SESSION['userid']))->result_array();
                $data['earnings']  = $this->db->get_where('tbl_earnings',array('customer_id'=>$_SESSION['userid']))->result_array();
                $data['purchases'] = $this->db->get_where('tbl_sales',array('buyer_id'=>$_SESSION['userid']))->result_array();
                $this->load->view('mlmuser/dashboard',$data);
            }
            else
            {
                redirect('login');
            }
        }
        
        public function request_payout()
        {
            if(isset($_SESSION['userid']))
            {
                $data['reffered']  = $this->db->get_where('tbl_refferal',array('refferral_id'=>$_SESSION['userid']))->result_array();
                $data['meta']      = $this->db->get_where('tbl_customers',array('customer_id'=>$_SESSION['userid']))->result_array();
                $data['earnings']  = $this->db->get_where('tbl_earnings',array('customer_id'=>$_SESSION['userid']))->result_array();
                $data['purchases'] = $this->db->get_where('tbl_sales',array('buyer_id'=>$_SESSION['userid']))->result_array();
                $this->db->order_by('id','desc');
                $data['pay_history'] = $this->db->get_where('tbl_request_withdrawls',array('customer_id'=>$_SESSION['userid']))->result_array();
                $this->load->view('mlmuser/payment_request',$data);
            }
            else
            {
                redirect('login');
            }
            
        }
        public function payOut()
        {
             if(isset($_SESSION['userid']))
            {
                $payouts  = $this->db->get_where('tbl_earnings',array('customer_id'=>$_SESSION['userid'],'withdrawls'=> 0))->result_array();
                $counter_payouts = 0;
                for($w=0; $w < count($payouts); $w++)
                {
                     $counter_payouts = $counter_payouts + $payouts[$w]['wallet'];
                }
                 $req_date = date('d-M-Y');
                   $this->db->insert('tbl_request_withdrawls',array('ammount'=>$counter_payouts,'customer_id'=>$_SESSION['userid'],'date_reruest'=>$req_date));
                   $this->db->where('customer_id',$_SESSION['userid']);
                   $this->db->where('withdrawls',0 );
                   $this->db->update('tbl_earnings',array('withdrawls' => 2));
                   redirect('request-payout?success');
            }
            else
            {
                redirect('login');
            }
            
        }
         public function find_orders()
        {
            if(isset($_SESSION['userid']))
            {
                $data['reffered']  = $this->db->get_where('tbl_refferal',array('refferral_id'=>$_SESSION['userid']))->result_array();
                $data['meta']      = $this->db->get_where('tbl_customers',array('customer_id'=>$_SESSION['userid']))->result_array();
                $data['earnings']  = $this->db->get_where('tbl_earnings',array('customer_id'=>$_SESSION['userid']))->result_array();
                $this->db->order_by('id','desc');
                $data['purchases'] = $this->db->get_where('tbl_sales',array('buyer_id'=>$_SESSION['userid']))->result_array();
                $this->db->order_by('id','desc');
                $data['pay_history'] = $this->db->get_where('tbl_request_withdrawls',array('customer_id'=>$_SESSION['userid']))->result_array();
                $this->load->view('mlmuser/my_orders',$data);
            }
            else
            {
                redirect('login');
            }
            
        }
        public function i_reffered()
        {
            if(isset($_SESSION['userid']))
            {
                $data['reffered']  = $this->db->get_where('tbl_refferal',array('refferral_id'=>$_SESSION['userid']))->result_array();
                $data['meta']      = $this->db->get_where('tbl_customers',array('customer_id'=>$_SESSION['userid']))->result_array();
                $data['earnings']  = $this->db->get_where('tbl_earnings',array('customer_id'=>$_SESSION['userid']))->result_array();
                $data['purchases'] = $this->db->get_where('tbl_sales',array('buyer_id'=>$_SESSION['userid']))->result_array();
                $this->db->order_by('id','desc');
                $data['pay_history'] = $this->db->get_where('tbl_request_withdrawls',array('customer_id'=>$_SESSION['userid']))->result_array();
                $this->load->view('mlmuser/my_refferers',$data);
            }
            else
            {
                redirect('login');
            }
            
        }
        //tree structure
        public function draw_tree()
        {
                $data['reffered']  = $this->db->get_where('tbl_refferal',array('refferral_id'=>$_SESSION['userid']))->result_array();
                $data['meta']      = $this->db->get_where('tbl_customers',array('customer_id'=>$_SESSION['userid']))->result_array();
                $data['earnings']  = $this->db->get_where('tbl_earnings',array('customer_id'=>$_SESSION['userid']))->result_array();
                $data['purchases'] = $this->db->get_where('tbl_sales',array('buyer_id'=>$_SESSION['userid']))->result_array();
                $this->db->order_by('id','desc');
                $data['pay_history'] = $this->db->get_where('tbl_request_withdrawls',array('customer_id'=>$_SESSION['userid']))->result_array();
                $this->load->view('mlmuser/tree_view',$data);
        }
        
        public function extend_tree()
        {
            //$this->db->limit(10, 20);
                $data['reffered']  = $this->db->get_where('tbl_refferal',array('refferral_id'=>$_SESSION['userid']))->result_array();
                $data['meta']      = $this->db->get_where('tbl_customers',array('customer_id'=>$_SESSION['userid']))->result_array();
                $data['earnings']  = $this->db->get_where('tbl_earnings',array('customer_id'=>$_SESSION['userid']))->result_array();
                $data['purchases'] = $this->db->get_where('tbl_sales',array('buyer_id'=>$_SESSION['userid']))->result_array();
                $this->db->order_by('id','desc');
                $data['pay_history'] = $this->db->get_where('tbl_request_withdrawls',array('customer_id'=>$_SESSION['userid']))->result_array();
                $this->load->view('mlmuser/tree_extended',$data);
        }
        
        
        //mlm system all cron jobs
        public function cron_job()
        {
            //start user-level updation
            $data_users = $this->db->get_where('tbl_customers',array('status'=>'active'))->result_array();
                for($u=0;$u< count($data_users);$u++)
                {
                    $data_counted_reffers = $this->db->get_where('tbl_refferal',array('refferral_id'=>$data_users[$u]['customer_id']))->result_array();
                    $member_reffered_are[$u] = count($data_counted_reffers);
                    //,'status'=> 'inactive'
                        $result = $this->db->get_where('tbl_levelStandard',array('ref_per_level <='=>$member_reffered_are[$u]))->result_array();
                        for($r=0;$r< count($result);$r++)
                        {
                            if($result[$r]['id'] == 10)
                            {
                                
                                if($member_reffered_are[$u] == $result[$r]['ref_per_level'])
                                {
                                    $this->db->where('customer_id',$data_users[$u]['customer_id']);
                                    $this->db->update('tbl_customers',array('level'=>$result[$r]['level_standard'],'package_id'=>$result[$r]['id'],'status'=> 'inactive'));
                                }
                            }
                            else if($result[$r]['id'] < 10)
                            {
                                    $this->db->where('customer_id',$data_users[$u]['customer_id']);
                                    $this->db->update('tbl_customers',array('level'=>$result[$r]['level_standard'],'package_id'=>$result[$r]['id']));
                            }
                            
                        }
                    //check if get refferals min 2 in 2 days
                                            $data_users[$u]['created_date'];
                                            $date1 = new DateTime($data_users[$u]['created_date']);
											$date2 = new DateTime(date('Y-m-d H:i:s'));
											$diff = $date1->diff($date2);
											if($diff->d > 3 && $data_users[$u]['level'] == 0)
											{
											    
											    $this->db->where('customer_id',$data_users[$u]['customer_id']);
                                                $this->db->update('tbl_customers',array('status'=> 'inactive'));
											}
                }
            //end user-level updation
            //all leftoer BV
                $AllSalesBVPC = $this->db->get('tbl_sales_detail')->result_array();
                $totalPVBV = 0;
                $PersalesPVBV = 0;
                for($c =0; $c< count($AllSalesBVPC);$c++)
                {
                   $PersalesPVBV = $AllSalesBVPC[$c]['pv'] + $AllSalesBVPC[$c]['bv'];
                   $totalPVBV = $totalPVBV + $PersalesPVBV;
                }
                $AllEarningsCus = $this->db->get('tbl_earnings')->result_array();
                //$totalPVBV = 0;
                $counterWallet = 0;
                for($c =0; $c< count($AllEarningsCus);$c++)
                {
                   $counterWallet = $counterWallet +  $AllEarningsCus[$c]['wallet'] ;
                }
                $leftoverShares = $PersalesPVBV -  $counterWallet;
                $this->db->where('id',1);
                $this->db->update('tbl_leftover',array('ammount'=>$leftoverShares));
            //end leftover BV
            //Top Earners
               $top_erners = $this->db->get_where('tbl_customers')->result_array();
                for($x=0; $x < count($top_erners); $x++)
                {
                    $this->db->where('customer_id',$top_erners[$x]['customer_id']);
                    $this->db->select_sum('ammount','sum');
                    $query = $this->db->get('tbl_request_withdrawls')->result_array();
                    //print_r($query[0]['sum']);
                    if(!empty($query[0]['sum']) && $query[0]['sum'] != 0)
                    {
                    $insert_sum =  array('amount'=>$query[0]['sum'],'customer_id'=>$top_erners[$x]['customer_id']);
                    $this->db->insert('top_earners',$insert_sum);
                    }
                }
        }
        //cronjob ends
}
?>