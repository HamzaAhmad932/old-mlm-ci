<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Sale extends CI_Controller {

        public function __construct()
	{
            parent::__construct();
            
            $this->load->model('Login_Model','login_model');
            $this->load->model('Category_Model','category_model');
            $this->load->model('Subcategory_Model','Subcategory_Model');
            $this->load->model('Sale_Model','Sale_Model');
            $this->load->helper(array('form', 'url'));
            $this->load->library('form_validation');
            $this->load->library('session');
            $this->load->database();
            $this->load->model('Product_Model');
            $this->load->model('Common_Modal');
            if($this->session->email == "")
            {
                redirect('account/login');
            }
            if($this->session->admin != 1)
            {
                redirect('account/login');
            }
	}
        
        
        
        
        public function index()
        {
           if(!empty($_POST))
		{
			$buyer_name = $this->input->post('buyer_name');
			$start_date = $this->input->post('start_date');
			$end_date = $this->input->post('end_date');
			$created_name = $this->input->post('created_name');
                        $allRecord = $this->Sale_Model->getAllHistoryRecord($buyer_name,$start_date,$end_date,$created_name);
			$output['sale_list'] = $allRecord;
			$output['start_date'] = $start_date;
			$output['end_date'] = $end_date;
                        $output['Buyer_Name'] = $this->Sale_Model->Buyer_Name();
			$output['created_names'] = $created_name;
			$output['buyername'] = $buyer_name;
                        $this->load->view('admin/sale/list',$output);
		}
                else
                {
                    $output['Buyer_Name'] = $this->Sale_Model->Buyer_Name();
                    $output['sale_list'] = $this->Sale_Model->get_list();
                    $this->load->view('admin/sale/list',$output);
                }
            
            
            
        }   
        
        
        
        public function shipped()
        {
            if(!empty($_POST))
		{
			$buyer_name = $this->input->post('buyer_name');
			$start_date = $this->input->post('start_date');
			$end_date = $this->input->post('end_date');
			$created_name = $this->input->post('created_name');
                    	$allRecord = $this->Sale_Model->getAllHistoryRecordStatus($buyer_name,$start_date,$end_date,$created_name);
			$output['sale_list'] = $allRecord;
			$output['start_date'] = $start_date;
			$output['end_date'] = $end_date;
                        $output['Buyer_Name'] = $this->Sale_Model->Buyer_Name_Status();
			$output['created_names'] = $created_name;
			$output['buyername'] = $buyer_name;
                        $this->load->view('admin/sale/list',$output);
		}
                else
                {
                    $output['size_list'] = $this->category_model->get_list_size();
                    $output['color_list'] = $this->category_model->get_list_color();
                    $output['Buyer_Name'] = $this->Sale_Model->Buyer_Name_Status();
                    $output['sale_list'] = $this->Sale_Model->shipped();
                    $this->load->view('admin/sale/shipped',$output);
                }
            
        }   
        
        public function SaleDetail($id)
        {
            $output['size_list'] = $this->category_model->get_list_size();
            $output['color_list'] = $this->category_model->get_list_color();
            $output['sale_detail'] = $this->Sale_Model->SaleDetail($id);
            $output['sale_address_detail'] = $this->Sale_Model->Address_Detail($id);
            $output['deliver_sale'] = $this->Sale_Model->Deliver_Sale($id);
            $this->load->view('admin/sale/detail',$output);
        }   
        public function SaleStatus($id)
        {
            $output['deliver_sale'] = $this->Sale_Model->SaleStatus($id);
            $this->session->set_flashdata('SUCCESSMSG','Order Successfully Placed!!');
            redirect('account/sale-detail/'.$id);
        }   
        public function SaleStatusCancel($id)
        {
            $output['deliver_sale'] = $this->Sale_Model->SaleStatusCancel($id);
            $this->session->set_flashdata('SUCCESSMSG','Order Canceled !!');
            redirect('account/sale-detail/'.$id);
        }   
         public function SaleStatusComplete($id)
        {
            $output['deliver_sale'] = $this->Sale_Model->SaleStatusComplete($id);
            $this->session->set_flashdata('SUCCESSMSG','Order Completed !!');
            //echo "<script>window.location='".base_url()."account/sale-detail/'".$id."';</script>";
            //ob_start();
            //redirect(base_url().'account/sale-detail/'.$id);
            echo "<script>window.location.assign('".base_url()."account/sale-detail/".$id."');</script>";
        }   
        //requests payouts
        public function payout()
        {
           
                  $output['requests'] = $this->db->get('tbl_request_withdrawls')->result_array();
                  $this->load->view('admin/payments/list_requests',$output);
                
            
        }   
        public function paid_rqst($id)
        {
            $this->db->where('id',$id);
            $this->db->where('status',1);
            $this->db->update('tbl_request_withdrawls',array('status'=>0,'date_paid'=>date('d-M-Y')));
            $getDataOfRequest = $this->db->get_where('tbl_request_withdrawls',array('id'=>$id))->result_array();
            $this->db->where('customer_id',$getDataOfRequest[0]['customer_id']);
            $this->db->where('withdrawls',2);
            $this->db->update('tbl_earnings',array('withdrawls'=>1));
            redirect('account/payout');
        }
     
        
}
