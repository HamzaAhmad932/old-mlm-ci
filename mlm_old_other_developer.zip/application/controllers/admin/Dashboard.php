<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends CI_Controller {

        public function __construct()
	{
            parent::__construct();
            
            $this->load->model('Admin_Dashboard_Model','Admin_Dashboard_Model');
            $this->load->helper(array('form', 'url'));
            $this->load->library('form_validation');
            $this->load->library('session');
            $this->load->database();
           if($this->session->admin != 1)
            {
                redirect('account/login');
            }
    	}
        
	public function index()
	{
            if($_SESSION['admin'] == 1)
            {
                $data['todaysale'] = $this->Admin_Dashboard_Model->todaysale();
                $data['totalsum'] = $this->Admin_Dashboard_Model->totalsum();
                $data['todaysalelist'] = $this->Admin_Dashboard_Model->todaysalelist();
                $data['counttotalsum'] = $this->Admin_Dashboard_Model->counttotalsum();
                $data['customer_list'] = $this->Admin_Dashboard_Model->customer_list();
                $data['totalpaid'] = $this->Admin_Dashboard_Model->totalpaid();
                $data['topEarnersx']= $this->Admin_Dashboard_Model->topEarners();
                $this->load->view('admin/dashboard',$data);
            }
            else
            {
                redirect('account/login');
            }
        }
        public function getAllComissionTable()
        {
            if($_SESSION['admin'] == 1)
            {
                $data['comisionSettings'] = $this->db->get('tbl_comission_dist')->result_array();
                $this->load->view('admin/comissionPercent',$data);
            }
             else
            {
                redirect('account/login');
            }
        }
        public function updatePercentage()
        {
            if($_SESSION['admin'] == 1)
            {
                $level = $this->input->post('level');
                $basic = $this->input->post('basic');
                $standard = $this->input->post('standard');
                $silver = $this->input->post('silver');
                $gold = $this->input->post('gold');
                $diamond = $this->input->post('diamond');
               
                foreach( $basic as $key => $n ) 
                {
                    $tital = $basic[$key] + $standard[$key] + $silver[$key] + $gold[$key] + $diamond[$key];
                     $this->db->where('level_num',$level[$key]);
                    $this->db->update('tbl_comission_dist',array('basic'=>$basic[$key], 'standard'=> $standard[$key], 'silver'=>$silver[$key], 'gold'=>$gold[$key], 'diamond'=>$diamond[$key],'total'=>$tital));
                   
                    //$level = $this->input->post('');
                }
                 redirect('admin/dashboard/getAllComissionTable');
            }
             else
            {
                redirect('account/login');
            }
        }
        public function getAllCriterion()
        {
            if($_SESSION['admin'] == 1)
            {
                $this->db->order_by('id','ASC');
                $data['levelCriterion'] = $this->db->get('tbl_levelStandard')->result_array();
                $this->load->view('admin/levelSetting',$data);
            }
             else
            {
                redirect('account/login');
            }
        }
        public function updateComission()
        {
            if($_SESSION['admin'] == 1)
            {
                $level_standard = $this->input->post('level_standard');
                $ref_per_level = $this->input->post('ref_per_level');
                $name_pkg = $this->input->post('name_pkg');
                
                foreach( $level_standard as $key => $n ) 
                {
                    $this->db->where('level_standard',$level_standard[$key]);
                    $this->db->update('tbl_levelStandard',array('level_standard'=>$level_standard[$key], 'ref_per_level'=> $ref_per_level[$key],'name_pkg'=>$name_pkg[$key]));
                   
                    //$level = $this->input->post('');
                }
                 redirect('admin/dashboard/getAllCriterion');
            }
             else
            {
                redirect('account/login');
            }
        }
        public function updateDefaultID()
        {
            $def_id = $this->input->post('defID');
            $this->db->where('id',1);
            $this->db->update('tbl_default_id',array('default_id'=>$def_id));
            redirect('admin/dashboard/getAllCriterion');
        }
        public function tree_company_user($c_id)
        {
            $dataarrayCU = array('customerTreeID' => $c_id);
            $this->session->set_userdata($dataarrayCU);
            $this->load->view('admin/user_tree');
            
        }
}
